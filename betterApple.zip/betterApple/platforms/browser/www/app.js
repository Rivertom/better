        //TELA DE ABERTURA

        function loadConfigs() {
            
            app.style.display = "block";
            currView="abertura";            
            login_Show();
             
         }
 
    function abertura_Show() {
        appBar.style.display = "none";
        abertura.style.display = "block";
        currView = "abertura";
        setTimeout(loadConfigs, 3000);
}

// Funcões da Tela de administraçao

function administrador_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Administração","showBackButton");
    
    document.getElementById(currView).style.display="none";
    currView = "administracao";
    document.getElementById(currView).style.display="block";

    removeToast();
}

// Enviar Push ::Tom::

function push()
{
    navigator.notification.prompt(
        'DIGITE A MENSSAGEM PUSH',  // message
        onPrompt,                  // callback to invoke
        'Enviar Notificação',            // title
        ['Okay','Exit'],             // buttonLabels
        'Já garantiu seu premio hoje?'                 // defaultText
    );
}

function onPrompt(results) {

    if(results.buttonIndex==1)
    {
    if(results.input1.length > 140){
        alert("mensagem maior que 140 caracteres");
        return;
    }
    par = `par={"mensagem":"${results.input1}"}`;
    doPost(serverPath + "usuarios/sendpush",par,(retorno)=>{
        ret=JSON.parse(retorno)
        if(ret.erros){
            navigator.notification.alert(ret.results.input1,null,"ERRO !!!");
            return;
        }

        if(ret.message){
            navigator.notification.alert(ret.results.input1,null,"ATENÇÃO !!!");
            return;
        }

    }); 
    }
}

//Zerar Ranking Mensal / Anual ::Tom:: / Push

function zerar_ranking(){
    navigator.notification.confirm(
        'Deseja Realmente zerar o rancking?', // message
         (opcao)=>{
            if(opcao==1){
                navigator.notification.confirm(
                    'Qual rancking deseja zerar?', // message
                     (opcao)=>{
                        par="par="+opcao;
                        doPost(serverPath+"apostas/zerarancking",par,(retorno)=>{
                            ret=JSON.parse(retorno)
                            if(ret.erros){
                                navigator.notification.alert(ret.mensagem,null,"ERRO !!!");
                                return;
                            }
                    
                            if(ret.message){
                                navigator.notification.alert(ret.mensagem,null,"ATENÇÃO !!!");
                                return;
                            }
                        });
                         
                    },            // callback to invoke with index of button pressed
                    'Zerar Rancking',           // title
                    ['Mensal','Anual']);     // buttonLabels
            }
            return;
        },            // callback to invoke with index of button pressed
        'Zerar Rancking',           // title
        ['Sim','Não']);
}

// Funcções de adicionar Jogos e controle deles
function add_games_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Adicionar Jogos","showBackButton");

    document.getElementById(currView).style.display="none";
    currView = "adicionar_jogos";
    adicionar_jogos.style.display = "block";

    removeToast();
}


function novoJogoSalvaResultado(indice, jogoid){
    var txtres1 = document.getElementById(`txt_time1_${indice}`);
    var txtres2 = document.getElementById(`txt_time2_${indice}`);

    var par = `par={"jogoid":"${jogoid}",
                    "time1res":"${txtres1.value}", 
                    "time2res":"${txtres2.value}"}`;
    doPost(serverPath+'jogos/salvaresultados',par,novoJogoListaJogos);

}

function novoJogoLvwJogos_show(retorno){

    if(retorno.indexOf("erros")!=-1){

        var ret = JSON.parse(retorno);

        if(ret.erros){
            navigator.notification.alert(ret.message,()=>{return;},"ERRO !!");
            return;
        }
    
        if(ret.mensagem){
            navigator.notification.alert(ret.message,()=>{return;},"ATENÇÂO !!");
            return;
        }
    
    }

    novoJogoLvwJogos.innerHTML = retorno;
}

function novoJogoExcluir(indice,id){

    var par = 'par={"id":"'+id+'"}';
    doPost(serverPath+'jogos/deletar',par,(retorno)=>{
        var ret=JSON.parse(retorno);

        if(ret.error){
            navigator.notification.alert(ret.message,()=>{return;},"ERRO !!!");
            return;
        }

        if(ret.mensagem){
            navigator.notification.alert(ret.message,()=>{return;},"ATENÇÃO !!!");
            return;
        }

        
    });


}

function novoJogoListaJogos(){
    
   var par = 'par={"rodadaid":"'+novoJogoRodadas.value+'"}';
    doPost(serverPath+'jogos/getjogosrodada',par,novoJogoLvwJogos_show);

}


// Ativar Cadastros
function perfilJogoGravado(retorno){

    novoJogoForm.style.display = "none";

    var ret= JSON.parse(retorno);

    if(ret.erros){
        navigator.notification.alert(ret.message,()=>{return;},"ERRO !!!");
        return;
    } else {
        if(ret.message){
            navigator.notification.alert(ret.message,()=>{return;},"ATENÇÃO !!!");
            return;
        }
    }     

}

function novoJogoSalvar(){

    if(novoJogoRodadas.selectedIndex==0){
        showToast("Favor selecionar a rodada !",2000);
        return;
    }

    if(novoJogoDtInicio.value==""){
        showToast("Data início inválida !",2000);
        return;
    }

    if(novoJogoHrInicio.value==""){
        showToast("Hora início inválida !",2000);
        return;
    }


    if(novoJogoTime1.selectedIndex==0){
        showToast("Favor selecionar o time 1 !",2000);
        return;
    }

    if(novoJogoTime2.selectedIndex==0){
        showToast("Favor selecionar o time 2 !",2000);
        return;
    }


    if(novoJogoTime1.value==novoJogoTime2.value){
        showToast("Os dois times são iguais !",2000);
        return;
    }
    var bonus ='0';
    if(novoJogoChkBonus.checked) bonus='1';

    var time1nome = novoJogoTime1.options[novoJogoTime1.selectedIndex].innerHTML
    var time2nome = novoJogoTime2.options[novoJogoTime2.selectedIndex].innerHTML

    var par = `par={"rodadaid":"${novoJogoRodadas.value}",
    "expira":"${novoJogoDtInicio.value} ${novoJogoHrInicio.value}",
    "time1id":"${novoJogoTime1.value}",
    "time2id":"${novoJogoTime2.value}",
    "bonus":"${bonus}",
    "time1nome":"${time1nome}",
    "time2nome":"${time2nome}",
    "local":"${LocalGame.value}"}`; 
    doPost(serverPath + "jogos/insert", par, perfilJogoGravado);

}

function creatNewGame(){

    if(novoJogoRodadas.value!='0'){
        novoJogoForm.style.display="block";
    } else showToast("Favor Selecionar a rodada !",2000);
}

function ativar_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Ativar Usuarios","showBackButton",);

    document.getElementById(currView).style.display="none";
    currView = "ativar_cads";
    document.getElementById(currView).style.display="block";


    removeToast();

    var par="par='void'";
    doPost(serverPath + 'usuarios/listaapp',par,addGamerListaUsuarios);
    
}

function addGamerStatusGravado(){

    navigator.notification.alert("Status Alterado com sucesso !",()=>{return;},"ATENÇÂO !!!");

    var par="par='void'";
    doPost(serverPath + 'usuarios/listaapp',par,addGamerListaUsuarios);

}

function addGamerOnConfirm(buttonIndex){
    
    if(buttonIndex==1){
        status="1";
    } else status='0';
    
    var par = 'par={"status":"' + status+ '","id":"' + user_id+'"}';
    doPost(serverPath + 'usuarios/savestatus',par,addGamerStatusGravado);
    
    return;
}


function addGamerChangeStatus(id,status){ 

    user_id=id;

    navigator.notification.confirm( 
        'O que vc deseja fazer?', // mensagem
         addGamerOnConfirm,            // callback 
        'Alteraração de Status',           // titulo
        ['ATIVAR','INATIVAR']); //ok
}

function addGamerListaUsuarios(retorno){


        var ret = JSON.parse(retorno);

        if(ret.erros){
            navigator.notification.alert(ret.message,()=>{return;},"ERRO !!");
            return;
        }
    
        if(ret.mensagem){
            navigator.notification.alert(ret.message,()=>{return;},"ATENÇÂO !!");
            return;
        }
    
    

    addgamerUserList.innerHTML = ""; 
    
    i=0;

    var htmlStr=`<tr><td align="center">`;
    while(i<=ret.length-1){
        if(ret[i].ativo=="0"){
            cordofundo="red";
            status ="INATIVO";

        }
        else{
            cordofundo="green";
            status="ATIVO";
        }

        


    htmlStr = htmlStr +
    `<table class="boxAtivarPlayer" style="width:90%">  
    <tr>
    <td align="center"  class="apostar" style="background:${cordofundo};text-align:center;" onclick="addGamerChangeStatus(${ret[i].id},${ret[i].ativo})">${status}</td>
    <tr>
    <tr>
        <td><p class="label white">${ret[i].nome}</p></td>
    <tr>
    <tr>
        <td><p class="label white">${ret[i].email}</p></td>
    <tr>
    </table>
    `;
    i++;
    }
    htmlStr = htmlStr;
    addgamerUserList.innerHTML = htmlStr; 

}

// Cadastro

//TELA PRE-LOGIN

var cadSexo = '5';
var cadPCD ='0';
var participando ="";
var participacao_oito = document.getElementById('Rodadas_8');
var participacao = document.getElementById('mensal_um');

var gFuncaoTela = "";

function cadastro_Show(func) {

    gFuncaoTela = func;
    verificacaoFeita=false;
    rodape.style.display = "none";

    //limpaCampos();

    cadTxtNome.value = "";
    cadTxtCPF.value = "";
    cadTxtEmail.value = "";
    cadTxtDataNasc.value = "",
    cadTxtCelular.value = "";
    cadTxtFoneFixo.value = "";
    cadTxtCEP.value = "";
    cadTxtRua.value = "";
    cadTxtNumero.value = "";
    cadTxtComplemento.value = "";
    cadTxtBairro.value = "";
    cadTxtCidade.value = "";



    $('#cadTxtCPF').mask("999.999.999-99");
    $('#cadTxtCEP').mask("99999-999");
    $('#cadTxtDataNasc').mask("99/99/9999");
    $('#cadTxtCelular').mask("(99)99999-9999");
    $('#cadTxtFoneFixo').mask("(99)9999-9999");

    if(gFuncaoTela=="cadastro"){
        configAppBarBasics("Criar Conta","showBackButton");
        //divSenha.style.display = "block";
        //divRepSenha.style.display = "block";
        cadCmdCadastrar.innerHTML = "CRIAR CONTA"
    } 


    //cadTxtBairro.disabled = true;
    //cadTxtRua.disabled = true;
    //cadTxtCidade.disabled = true;


    document.getElementById(currView).style.display="none";
    currView = "cadastro";
    document.getElementById(currView).style.display="block";


    if(gFuncaoTela=="alterar"){
        configAppBarBasics("Minha Conta","showBackButton");
        //divSenha.style.display = "none";
        //divRepSenha.style.display = "none";
        cadCmdCadastrar.innerHTML = "ALTERAR"

        doPost(serverPath+'apostas/ranking',`par={"userid":"${gUser.id}","per":"1"}`,(result)=>{
            res = JSON.parse(result);
            
            for(i=0;i<=res.rkg.length-1;i++){
        
                if(res.rkg[i].userid==gUser.id){ // achou ele
                    cadUserFoto.src = "https://www.devicecontrols.com.br/bolao/"+res.rkg[i].userid +".jpg"
                }
        
            }
        });

        
   
        cadTxtNome.value = gUser.nome;

        /*
        cpfAux = gUser.cpf;
        cpf = cpfAux.substring(0,3);
        cpf=cpf+".";
        cpf=cpf+cpfAux.substring(3,6);
        cpf=cpf+".";
        cpf=cpf+cpfAux.substring(6,9);
        cpf=cpf+"-";
        cpf=cpf+cpfAux.substring(9,11);*/

        if(gUser.cpf) cadTxtCPF.value = gUser.cpf.substring(0,3) + "." + gUser.cpf.substring(3,6) + "." + gUser.cpf.substring(6,9) + "-" + gUser.cpf.substring(9,11);
        cadTxtEmail.value = gUser.email;
        cadTxtDataNasc.value = gUser.datanasc;
        if(gUser.celular) cadTxtCelular.value = "(" + gUser.celular.substring(0,2)+")"+gUser.celular.substring(2,7)+"-"+gUser.celular.substring(7,11);
        if(gUser.fixo) cadTxtFoneFixo.value = "(" + gUser.fixo.substring(0,2)+")"+gUser.fixo.substring(2,6)+"-"+gUser.fixo.substring(6,10);
        if(gUser.cep.length > 5) {
            cadTxtCEP.value = gUser.cep.substring(0,5)+"-"+gUser.cep.substring(5,8);
        } else {
            cadTxtCEP.value = "";
        }
        cadTxtRua.value = gUser.rua;
        cadTxtNumero.value = gUser.num;
        cadTxtComplemento.value= gUser.comp;
        cadTxtBairro.value = gUser.bairro;
        cadTxtCidade.value = gUser.cidade;

    } 


    removeToast();

}

function cadTestaCPF(strCPF) {
    var Soma;
    var Resto;
    Soma = 0;
    if (strCPF == "00000000000") return false;

    for (i = 1; i <= 9; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (11 - i);
    Resto = (Soma * 10) % 11;

    if ((Resto == 10) || (Resto == 11)) Resto = 0;
    if (Resto != parseInt(strCPF.substring(9, 10))) return false;

    Soma = 0;
    for (i = 1; i <= 10; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (12 - i);
    Resto = (Soma * 10) % 11;

    if ((Resto == 10) || (Resto == 11)) Resto = 0;
    if (Resto != parseInt(strCPF.substring(10, 11))) return false;
    return true;
}

function cadVerificaCPF() {

    //formataCRA(txtCRA.value);
    cpfNum = cadTxtCPF.value.replace(".", "");
    while (cpfNum.indexOf(".") != -1) {
        cpfNum = cpfNum.replace(".", "");
    }
    cpfNum = cpfNum.replace("-", "");

    if (cpfNum.length == 11) {
        if (cadTestaCPF(cpfNum)) {
           var a=1 ; //doPost(serverPath + 'BuscaDadosUsuarioPorCPF', "cpf=" + cpfNum, avaliaResultado);
        } else {

            showToast("CPF inválido. Favor verificar!", 2000);
            cadTxtCPF.focus();
        }
    } else {
        showToast("CPF inválido. Favor verificar!", 2000);
        cadTxtCPF.focus();

    }
}


function criarContaRetApi(retorno){

    var ret=JSON.parse(retorno);

    if((ret.erros)||(ret.message)) {
        if(ret.erros){
            var cabecalho = "ERRO !!!";
    
        } else {
            var cabecalho = "ATENÇÃO !!!";

        }

        alerta(ret.mensagem,cabecalho,null);
        return;
    }

}
// box cheked para participação!
function testechek_um()
{

        if ( participacao.checked ) 
        {
            participando = 1;
        }
}
function testechek_oito()
{
    
        if (participacao_oito.checked) 
        {
            participando = 8;
        }
}


function cadastroCriarConta(){

    if(gFuncaoTela=='cadastro'){
    function alertDismissed() {
        if(participando == 1)
        {
            var ref = cordova.InAppBrowser.open("https://www.mercadopago.com/mlb/checkout/start?pref_id=423155552-734c65a8-2582-4484-ae53-c3b7bf85a906", '_blank', 'location=yes');
        }
    
        if(participando == 8)
        {
            var ref = cordova.InAppBrowser.open("https://www.mercadopago.com/mlb/checkout/start?pref_id=423155552-87209249-e896-40c4-889b-873eb11cf658", '_blank', 'location=yes');
        }
    }
    
    navigator.notification.alert(
        'Sua Senha para primeiro acesso é "troca123"',  // message
        alertDismissed,         // callback
        'Cadastro Realizado com Sucesso',            // title
        'Ok entendi'                  // buttonName
    );
    }


    var cpfNum="";

    if(cadTxtNome.value==""){
        showToast("Favor Preencher o Nome !",2000);
        return;
    }

   
    if (gFuncaoTela != "preinscricao") {
        if (cadTxtCPF.value == "") {
            showToast("Favor Preencher o CPF !", 2000);
            return;
        } else {
            cpfNum = cadTxtCPF.value.replace(".", "");
            while (cpfNum.indexOf(".") != -1) {
                cpfNum = cpfNum.replace(".", "");
            }
            cpfNum = cpfNum.replace("-", "");
        }
    } else {
        if (cadTxtCPF.value != "") {
            cpfNum = cadTxtCPF.value.replace(".", "");
            while (cpfNum.indexOf(".") != -1) {
                cpfNum = cpfNum.replace(".", "");
            }
            cpfNum = cpfNum.replace("-", "");
            if(cpfNum==gUser.cpf){
                navigator.notification.alert("O CPF utilizado não pode ser o mesmo CPF do usuário do aplicativo !",null,"ATENÇÃO !!!");
                return;
            }
        }
    }

    if(cadTxtDataNasc.value==""){
        showToast("Favor Preencher a data de nascimento !",2000);
        return;
    }

    if(cadTxtDataNasc.value.length != 10){
        showToast("Data de Nascimento inválida",2000);
        return;
    }

    if (cadTxtEmail.value == "") {
        showToast("Favor informar o seu email !", 2000);
        return;
    }

    if(cadTxtEmail.value.indexOf("@")==-1){
        showToast("e-mail inválido !", 2000);
        return;

    } else {
        if(cadTxtEmail.value.indexOf("@")==cadTxtEmail.value.length-1){
            showToast("e-mail inválido !", 2000);
            return;
        }
    }

    if ((cadTxtCelular.value == "") && (cadTxtFoneFixo.value == "")) {
        showToast("Favor informar ao menos um telefone !", 2000);
        return;
    }

    cel="";
    if(cadTxtCelular.value.length > 0) {
        if(cadTxtCelular.value.length != 14) {
            showToast("Numero de Telefone Celular inválido !", 2000);
            return;
        } else {
            cel = cadTxtCelular.value.replace("(","");
            cel = cel.replace(")","");
            cel = cel.replace("-","");
        }
    }

    tel="";
    if(cadTxtFoneFixo.value.length > 0) {
        if(cadTxtFoneFixo.value.length != 13) {
            showToast("Numero de Telefone Fixo inválido !", 2000);
            return;
        } else {
            tel = cadTxtFoneFixo.value.replace("(","");
            tel = tel.replace(")","");
            tel = tel.replace("-","");

        }
    }


    /*
    if (cadTxtFoneFixo.value == "") {
        showToast("Favor informar o telefone fixo !", 2000);
        return;
    }
    */
    if (cadTxtCEP.value == "") {
        showToast("Favor informar o CEP !", 2000);
        return;
    }
 
    if (cadTxtCEP.value.length != 9) {
        showToast("CEP inválido !", 2000);
        return;
    }


    if ((cadTxtRua.value == "")||(cadTxtNumero.value == "")||(cadTxtBairro.value == "")||(cadTxtCidade.value == "")) {
        showToast("Favor informar o endereço completo !", 2000);
        return;
    }

    /*
    if(gFuncaoTela=="cadastro"){
        if (cadTxtSenha.value == "") {
            showToast("Favor informar o senha !", 2000);
            return;
        } 
    
        if (cadTxtRepSenha.value != cadTxtSenha.value) {
            showToast("Senhas não conferem !", 2000);
            return;
        }
    }
    */

    if(gFuncaoTela=="preinscricao"){

        novaConta = {nome : cadTxtNome.value.toUpperCase(), nome_social:cadTxtNomeSocial.value.toUpperCase(),
            cpf : cpfNum,
            email:cadTxtEmail.value.toUpperCase(),
            dt_nasc:cadTxtDataNasc.value,
            celular:cel,
            fixo:tel,
            cep:cadTxtCEP.value.replace("-",""),
            rua:cadTxtRua.value.toUpperCase(),
            num:cadTxtNumero.value,
            comp:cadTxtComplemento.value.toUpperCase(),
            bairro:cadTxtBairro.value.toUpperCase(),
            resp_id:gUser.Id,
            grauParenResp:cadCboParentesco.value
        }; 
    }
    if(gFuncaoTela=="cadastro"){
        novaConta = {nome : cadTxtNome.value.toUpperCase(),
            cpf : cpfNum,
            email:cadTxtEmail.value.toUpperCase(),
            dt_nasc:cadTxtDataNasc.value,
            celular:cel,
            fixo:tel,
            cep:cadTxtCEP.value.replace("-",""),
            rua:cadTxtRua.value.toUpperCase(),
            num:cadTxtNumero.value,
            comp:cadTxtComplemento.value.toUpperCase(),
            bairro:cadTxtBairro.value.toUpperCase(),
            cidade:cadTxtCidade.value.toUpperCase()
        };
    }        

    if(gFuncaoTela=="alterar"){
        novaConta = {id:gUser.id,nome : cadTxtNome.value.toUpperCase(),
            cpf : cpfNum,
            email:cadTxtEmail.value.toUpperCase(),
            dt_nasc:cadTxtDataNasc.value,
            celular:cel,
            fixo:tel,
            cep:cadTxtCEP.value.replace("-",""),
            rua:cadTxtRua.value.toUpperCase(),
            num:cadTxtNumero.value,
            comp:cadTxtComplemento.value.toUpperCase(),
            bairro:cadTxtBairro.value.toUpperCase(),
            cidade:cadTxtCidade.value.toUpperCase(),
            senha:gUser.senha
        };
    }        


    var par= 'par=' + JSON.stringify(novaConta);

    if(gFuncaoTela=="alterar"){
        doPost(gServerPath+'usuarios/alterar',par,(retorno)=>{

            var ret=JSON.parse(retorno);
    
            if(ret.erros) {
                alerta(ret.mensagem,"ERRO !!",null);
                return;
            }    
            if(ret.mensagem){
                alerta(ret.message,"ATENÇÃO !!!",null);
            }

            menu_principal_Show();

        });
    }  

    if(gFuncaoTela=="cadastro"){
        doPost(gServerPath+`usuarios/insert`,par,(retorno)=>{

            var ret=JSON.parse(retorno);
    
            if(ret.erros) {
                alerta(ret.mensagem,"ERRO !!",null);
                return;
            }    
            if(ret.message){
                alerta(ret.mensagem,"ATENÇÃO !!!",null);
            }
            localStorage.setItem("sjv_cpf_reset",cadTxtCPF.value);
        });
    }  

    if(gFuncaoTela=="preinscricao") {
        
        navigator.notification.confirm("Confirma a pré-inscrição ?",(botao)=>{
            if(botao==1){

                var t = JSON.stringify(listaTurmas.turmas[gTurmaSelInd]);
                var a = JSON.stringify(novaConta);
                par = `pturma=${t}&paluno=${a}&pusua_id=${gUser.Id}`;
                doPost(gServerPath + "TurmasInscrever", par,(retorno)=>{
        
                    var ret=JSON.parse(retorno);
            
                    if((ret.erros)||(ret.message)) {
                        if(ret.erros){
                            var cabecalho = "ERRO !!!";
                    
                        } else {
                            var cabecalho = "ATENÇÃO !!!";
                
                        }
                        alerta(ret.mensagem,cabecalho,null);
                        return;
                    }
                    comprovante_inscricao_Show(ret.texto);
                });

            }

        },"Confirmar Inscrição",['SIM','NÃO']);

    } 

}


// EVENTOS DA PAGINA

cadTxtNome.onblur = function (){
    if(cadTxtNome.value!=""){
        if(!validaInputSoLetra(cadTxtNome.value)){
            showToast("Nome contém números !",2000);
        }
    }
}

cadTxtNome.onkeypress = function (e){
    if(e.keyCode==13){
        if(cadTxtNome.value!=""){
            if(!validaInputSoLetra(cadTxtNome.value)){
                showToast("Nome contém números !",2000);
            }
        }
    }

}



cadTxtCPF.onkeypress = function (e) {
    if (e.keyCode == 13) {
        cadVerificaCPF();
    }
}

cadTxtCPF.onblur = function () {
    if (!verificacaoFeita) {
        if (cadTxtCPF.value != "") {
            cadVerificaCPF();
        }
    }
}

cadTxtCPF.onfocus = function () {
    cpfStatus = "invalido";
    verificacaoFeita = false;
}


cadTxtCEP.onkeypress = function (e) {
    if (e.keyCode == 13) {
        if(cadTxtCEP.value.length == 9){
            cadTxtRua.value = "";
            cadTxtBairro.value = "";
            cadTxtCidade.value = "";
        
            cep = cadTxtCEP.value.replace(/\D/g, '');
            doGet('https://viacep.com.br/ws/'+ cep + '/json/',preencheCepApiRet)
    
        } else{
            showToast("CEP inválido !",2000);
            return;
        }
    }

}

cadTxtCEP.onblur = function () {
    if(cadTxtCEP.value.length ==9){
        cadTxtRua.value = "";
        cadTxtBairro.value = "";
        cadTxtCidade.value = "";
        
        cep = cadTxtCEP.value.replace(/\D/g, '');
        doGet('https://viacep.com.br/ws/'+ cep + '/json/',preencheCepApiRet)
    
    } else{
            showToast("CEP inválido !",2000);
            return;
    }
}

cadTxtDataNasc.onblur = function (){
    if(cadTxtDataNasc.value!=""){

        if(!validaData(cadTxtDataNasc.value)){
            cadTxtDataNasc.focus();
            showToast("Data inválida !",2000);
        }
    }
}

cadTxtDataNasc.onkeypress = function (e){
    if(e.keyCode==13){
        if(cadTxtDataNasc.value!=""){
            if(!validaData(cadTxtDataNasc.value)){
                showToast("Data inválida !",2000);
            }
        }
    }
}

cadTxtNome.onblur = function (){
    if(cadTxtNome.value!=""){
        if(!validaInputSoLetra(cadTxtNome.value)){
            showToast("Nome contém números !",2000);
            cadTxtNome.focus();
        }
    }
}

cadTxtNome.onkeypress = function (e){
    if(e.keyCode==13){
        if(cadTxtNome.value!=""){
            if(!validaInputSoLetra(cadTxtNome.value)){
                showToast("Nome contém números !",2000);
                cadTxtNome.focus();
            }
        }
    }

}
/*
cadTxtSenha.onblur = function (){
    if(cadTxtSenha.value!=""){
        if(cadTxtSenha.value.length<6){
            showToast("Senha menor que 6 caracteres !",2000);
            cadTxtSenha.focus();
        }
        if(cadTxtSenha.value.length>8){
            showToast("Senha maior que 8 caracteres !",2000);
            cadTxtSenha.focus();
        }
    }
}

cadTxtSenha.onkeypress = function (e){
    if(e.keyCode==13){
        if(cadTxtSenha.value!=""){
            if(cadTxtSenha.value.length<6){
                showToast("Senha menor que 6 caracteres !",2000);
                cadTxtSenha.focus();
            }
            if(cadTxtSenha.value.length>8){
                showToast("Senha maior que 8 caracteres !",2000);
                cadTxtSenha.focus();
            }
        }
    }

}
*/


function preencheCepApiRet(retorno){

    dadosCep = JSON.parse(retorno);

    if(dadosCep.erro==true){
        alerta("CEP Inválido !","ERRO !!!", null);
        return;
    }

    cadTxtRua.value = dadosCep.logradouro;
    cadTxtBairro.value = dadosCep.bairro;
    cadTxtCidade.value = dadosCep.localidade;

}

function validaData(data){

    if(data.length != 10) return false;

    d = data.split("/");

    if((d[0]>31)||(d[0]<1)) return false
    if((d[1]>12)||(d[1]<1)) return false;
    if(d[2].length<4) return false;

    if(d[1]=="02") {
        if(d[0]>29) return false;
    }
    if(d[1]=="04") {
        if(d[0]>30) return false;
    }
    if(d[1]=="06") {
        if(d[0]>30) return false;
    }
    if(d[1]=="09") {
        if(d[0]>30) return false;
    }
    if(d[1]=="11") {
        if(d[0]>30) return false;
    }
    return true;

}


function validaInputSoLetra(texto){
    var filtro = /^([a-zA-Zà-úÀ-Ú]|\s+)+$/;

    if(!filtro.test(texto)){
        return false;
    }

    return true;
}

function cadGetUserImage(){

    if(gFuncaoTela=="cadastro"){
        alerta("Não é possível escolher imagem sem conta criada. Crie uma conta e depois selecione sua imagem!","ATENÇÃO !!",null);
        return;
    }

    navigator.notification.confirm("O que você desja ?",(source)=>{
        if(source==2){
            navigator.camera.getPicture(
                (imagem)=>{
                    cadUserFoto.src = imagem;
                },
                function (message) { alert('get picture failed'); },
                {
                    quality: 50,
                    destinationType: navigator.camera.DestinationType.FILE_URI,
                    sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY
                }
            );
        
        }
        if(source==1){
            navigator.camera.getPicture(
                (imagem)=>{
                    cadUserFoto.src = imagem;
                },
                function (message) { alert('get picture failed'); },
                {
                    quality: 50,
                    destinationType: navigator.camera.DestinationType.FILE_URI,
                    sourceType: navigator.camera.PictureSourceType.CAMERA
                }
            );
        
        }

    },"Sua Imagem",['Câmera','Imagem']);


}

function uploadPhoto(){
    //alert(imgURI);
    var options = new FileUploadOptions();
    options.fileKey="file";
    options.fileName=cadUserFoto.src.substr(cadUserFoto.src.lastIndexOf('/')+1);
    options.mimeType="image/jpeg";
    
    var params = new Object();
    params.user_id = gUser.id;
    
    options.params = params;
    options.chunkedMode = false;   alert(imgURI);
    var ft = new FileTransfer();
    ft.upload(cadUserFoto.src,"https://www.devicecontrols.com.br/bolao/ws_saveimage.php", win, fail, options);
}

function win(r) {
    if(r.response.indexOf("Erro")!=-1){
        navigator.notification.alert(r.response,()=>{return;},"ERRO !!!");
        return;
    }
    cadastroCriarConta();
}

function fail(error) {
    navigator.notification.alert(`Erro de comunicção com o servidor. Código:${error.code}'}`,()=>{return;},"ERRO !!!");

    //console.log("upload error source " + error.source);
    //console.log("upload error target " + error.target);
}




//TELA PRE-LOGIN

var cadSexo = '5';
var cadPCD ='0';

var gFuncaoTela = "";

// contato

function contato_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Contato","showBackButton",);

    document.getElementById(currView).style.display="none";
    currView = "contato";
    document.getElementById(currView).style.display="block";


    removeToast();
    
}

function mensagemEnviada(retorno){
    var ret = JSON.parse(retorno);
    if(ret.error){
        navigator.notification.alert(ret.message,()=>{return;},"ERRO !");
    }
    if(ret.mensagem){
        navigator.notification.alert(ret.message,()=>{return;},"ATENÇÃO !");
    }

    return;        
}        

function faleConoscoEnviar_click() {
  
            
    if (txtSugestao.value == "") {
        showToast("Favor digitar a sugestão !", 2000);
        txtSugestao.focus();
        return;
    }
   
    //mensagemEnviada("OK");
    //alert(txtSugestao.value);
    var par = `par={"nome":"${gUser.nome}","email":"${gUser.email}","mensagem":"${txtSugestao.value}"}`;
    doPost(serverPath + "usuarios/faleconosco", par, mensagemEnviada);

            
}

// login

//TELA PRE-LOGIN
var verificacaoFeita = false;
var craFormatado = "";

var loginErroCadastro = "";

var logintxtEmail = document.getElementById("logintxtEmail");
var logintxtSenha = document.getElementById("logintxtSenha");
var loginBtnLogin = document.getElementById("loginBtnLogin");

function login_Show() {

    appBar.style.display = "none";

   // logintxtCPF.focus();

   document.getElementById(currView).style.display="none";
   currView = "login";
   document.getElementById(currView).style.display="block";

    removeToast();

                var gUser = JSON.parse(localStorage.getItem("better_usuario"));
            if(gUser!=null){
                logintxtEmail.value = gUser.email;
            } else logintxtEmail.value = "";

            login.style.display = "block"; //aqui exibe  div
            
            verificacaoFeita=false;
            resetaSenha=false;
            user = null;
}

function loginCriarConta() {
    login.style.display = "none";
    rota('cadastro');

}

function loginResetarSenha() {

    if(logintxtEmail.value==""){
        alert("Favor Confira seu email ")
    }

    var par = 'par={"email":"' + logintxtEmail.value+ '"}';
    doPost(serverPath + "usuarios/solicitatrocasenha", par, (retorno)=>{
        var ret= JSON.parse(retorno);
        navigator.notification.alert(ret.message,()=>{return;},"ATENÇÂO !!!");
    });
   
}

function loginTrocaSenha(){
   navigator.notification.alert("Sua senha necessita ser alterada !",()=>{return;},"ATENÇÂO !!!");
   ///login.style.display="none";
   //rota('resgata_senha');
 navigator.notification.prompt("Nova senha:",function (results){
        if(results.buttonIndex==2){
            limpaCampos();
            return;
        }          
        
        if(results.input1==""){
            limpaCampos();
            return;
        }

        var par = 'par={"id":"' + gUser.id+ '","senha":"' + results.input1+'"}';
        doPost(serverPath + "usuarios/savesenha", par, loginSenhaTrocada);
        
    },"ATENÇÃO !!!",['Confirmar','Cancelar'],"");
 
}

function loginSenhaTrocada(retorno){

    function alertDismissed() {
        login_Show()
    }
    
    navigator.notification.alert(
        'Sua foi trocada com sucesso',  // message
        alertDismissed,         // callback
        'Senha Alterada',            // title
        'OK'                  // buttonName
    );   
    return;

}



function loginUsuarioGravado(retorno){

    gUser=JSON.parse(retorno);

    /*if(gUser.versao!="2.0.1"){
        navigator.notification.alert("Há uma nova versão disponível do aplitivo !",voidAlertCallBack,"ATENÇÂO !!!"); 
        return;

    }*/

    if(gUser.error){

        navigator.notification.alert(gUser.message,voidAlertCallBack, "ERRO !!!"); 
        return;
    }

    if(!gUser.error){
  
        if(gUser.comando){
            if(gUser.message=="REDEFINIR_SENHA"){
                loginTrocaSenha();
                return;
            }
        }

        if(gUser.mensagem){
            navigator.notification.alert(gUser.message,()=>{return;},"ATENÇÂO !!!");
            return;
        }    

        if((gUser.cpf==null)||(gUser.cep=='0')){
            navigator.notification.alert("Detectamos que seu cadastro está incompleto ! Favor completar !",
                                          cadastro_Show('alterar'),
                                          "ATENÇÃO !!!");
            return;                              
        }

        localStorage.setItem("better_usuario",retorno);
        login.style.display="none";
        var termoStatus = localStorage.getItem("betbrasil_termo");
        login.style.display="none";
        if(termoStatus==null){
            menu_principal_Show();
        } 
        else 
        {
            menu_principal_Show();
        }
        return;
    }


 
}


//resetar senha
function loginResetarSenha() {

    if(logintxtEmail.value==""){
        alert("Favor Confira seu email ")
    }

    var par = 'par={"email":"' + logintxtEmail.value+ '"}';
    doPost(serverPath + "usuarios/solicitatrocasenha", par, (retorno)=>{
        var ret= JSON.parse(retorno);
        navigator.notification.alert(ret.message,()=>{return;},"ATENÇÂO !!!");
    });
   
}

function loginEntrar_click() {
  
    
    if (logintxtEmail.value == "") {
        showToast("Favor informar o seu email !", 2000);
        logintxtEmail.focus();
        return;
    }

    if(logintxtEmail.value.indexOf("@")==-1){
        showToast("e-mail inválido !", 2000);
        logintxtEmail.focus();
        return;

    } else {
        if(logintxtEmail.value.indexOf("@")==logintxtEmail.value.length-1){
            showToast("e-mail inválido !", 2000);
            logintxtEmail.focus();
            return;
        }
    }

    if (logintxtSenha.value == "") {
        showToast("Favor informar a Senha !", 2000);
        logintxtSenha.focus();
        return;
    }


   
    
        var par = 'par={"email":"' + logintxtEmail.value+ '","senha":"' + logintxtSenha.value+'"}';
        doPost(serverPath + "usuarios/login", par, loginUsuarioGravado);
        //doGet(serverPath + "usuarios/login/"+ logintxtEmail.value+"/"+ logintxtSenha.value,loginUsuarioGravado);    
}

logintxtSenha.onkeypress= function(e) {
    if(e.keyCode==13){
        loginEntrar_click();
        return;
    }

}

// Menu Principal
//TELA MENU PRINCIPAL
gSecId=0;
var lblNome = document.getElementById("menprinclblNome");
var posicao = document.getElementById("pontosUser");
//funçao Show
function menu_principal_Show() {
   
    rodape.style.display="none";
    
    configAppBarBasics("Jogos","showBackButton");
    document.getElementById("imgAppBarButton1").src="img/icone_sobrea3otica.png";
    document.getElementById("appBarButton1").style.display="block";
    document.getElementById("imgAppBarButton2").src="img/world.png";
    document.getElementById("appBarButton2").style.display="block";
    document.getElementById("imgAppBarButton4").src="img/icone_faleconosco2.png";
    document.getElementById("imgAppBarButton4").style.display="block";
    document.getElementById("appBarButton4").style.display="block";

    if(gUser.adm!=1){
        document.getElementById("imgAppBarButton3").src="img/admin.png";
        document.getElementById("appBarButton3").style.display="none";

    } else {
        document.getElementById("imgAppBarButton3").src="img/admin.png";
        document.getElementById("appBarButton3").style.display="block";
    }

    document.getElementById(currView).style.display="none"; 
    currView = "menu_principal"; 
    document.getElementById(currView).style.display="block";


    var par = "par=";
    doPost(serverPath+'jogos/loadconfigs','par={"nome":"1"}',exibeTela);    

    removeToast();

}






function principalSalvaAposta(indice, jogoid,status){
    var txtres1 = document.getElementById(`principaltxt_time1_${indice}`);
    var txtres2 = document.getElementById(`principaltxt_time2_${indice}`);
    
    
    //var status = document.getElementById(`jogoStatus_${indice}`); Apostar is not defined! qaul linha



    if(status=="Encerrado"){ //agora quem expirou fala periodo expirado quem não expirou tambem!!!!!!!!
        navigator.notification.alert("Período de apostas encerrado !",()=>{return;},"ATENÇÃO !!!");
        return;
    }

    if(status=="Andamento"){ //agora quem expirou fala periodo expirado quem não expirou tambem!!!!!!!!
        navigator.notification.alert("Jogo em andamento !",()=>{return;},"ATENÇÃO !!!");
        return;
    }


    if(txtres1.value==""){
        showToast("Resultado time 1 inválido!",2000);
        return;
    }

    if(txtres2.value==""){
        showToast("Resultado time 2 inválido!",2000);
        return;
    }


    var par = `par={"jogoid":"${jogoid}",
                    "rodadaid":"${principalRodadas.value}",
                    "userid":"${gUser.id}",     
                    "time1res":"${txtres1.value}", 
                    "time2res":"${txtres2.value}"}`;
    doPost(serverPath+'apostas/salvar',par,principalListaJogos);

}

function principalLvwJogos_show(retorno){
    

    if(retorno.indexOf("erros")!=-1){

        var ret = JSON.parse(retorno);

        if(ret.erros){
            navigator.notification.alert(ret.message,()=>{return;},"ERRO !!");
            return;
        }
    
        if(ret.mensagem){
            navigator.notification.alert(ret.message,()=>{return;},"ATENÇÂO !!");
            return;
        }
    
    }

    var ret = JSON.parse(retorno);
    i=0;
    var htmlStr=`<tr><td align="center">`;
    corTexto="white";
    expirou="livre";
    disa="";

    cmdApostar.style.display="none";
    while(i<=ret.length-1){
        corTexto="white";
        if(ret[i].status=="ANDAMENTO"){
            corTexto="green";
            cordofundo="yellow";
            expirou ="Andamento";
            disa="disabled";

        } else {
            if(ret[i].status=="EXPIRADO"){
                cordofundo="red";
                expirou ="Encerrado";
                disa="disabled";
            }  else{
                cordofundo="green";
                expirou ="Apostar";
                disa="";
            }
        }

        var auxJogo = ret[i].expira.split(' ');
        var dataJogo = auxJogo[0].split('-');

        var bonus=""
        if(ret[i].bonus=='1'){
            bonus="BONUS";
        }

        t1Nome = ret[i].time1nome.toLowerCase();
        t2Nome = ret[i].time2nome.toLowerCase();;
        
        htmlStr  = htmlStr + 
        `
        <table class="box_better" style="width:100%">
        <tr>
            <td align="center" style="width: 10%"></td>
            <td style="width: 30%" align="center" class="local_Part"><label>${ret[i].local}</label></td>
            <td style="width: 20%" align="center" class="statusGame" style="background:${cordofundo}">${expirou}</td>
            <td style="width: 30%" align="center" class="local_Part"><label>${ret[i].local}</label></td>
            <td  align="center" style="width: 10%"></td>
        </tr>
        <tr>
            <td style="width: 10%" align="center"><img src="img/${t1Nome}.png" width="90%" height="30px"></td>
            <td style="width: 30%" align="center" class="time">${ret[i].time1nome}</td>
            <td style="width: 20%" align="center" class="relogio">${auxJogo[1]}</td>
            <td style="width: 30%" align="center" class="time">${ret[i].time2nome}</td>
            <td style="width: 10%"  align="center"><img src="img/${t2Nome}.png" width="90%" height="30px"></td>
        </tr>
        <tr>
            <td style="width: 10%" align="center" class="Result" value="${ret[i].aposta1}">${ret[i].time1res}</td>
            <td style="width: 30%" align="center"><input ${disa} aposta="a" id="ap_1_${gUser.id}_${ret[i].rodadaid}_${ret[i].id}_${expirou}" type="number" maxlength="2" class="inserir_Result" value="${ret[i].aposta1}"></td>
            <td style="width: 20%" align="center" class="dataGame">${dataJogo[2]}/${dataJogo[1]}/${dataJogo[0]}</td>
            <td style="width: 30%" align="center"><input ${disa} aposta="a" id="ap_2_${gUser.id}_${ret[i].rodadaid}_${ret[i].id}_${expirou}" type="number" maxlength="2" class="inserir_Result" value="${ret[i].aposta2}"></td>
            <td style="width: 10%" align="center"class="Result" value="${ret[i].aposta2}">${ret[i].time2res}</td>  
        </tr>
        <tr>
            <td style="width:10%"></td>
            <td style="width:30%"></td>
            <td style="width: 20%" class="bonus">${bonus}</td>
            <td style="width:30%"></td>
            <td style="width:10%" style="float:right">
        </tr>
    </table>
    <br>
`;
        i++;
    }    
    htmlStr=htmlStr + "</td></tr>";
    principalLvwJogos.innerHTML = htmlStr;

    if(ret.length > 0) cmdApostar.style.display="block";

    

    

}



function salvarApostas(){

    var x = document.querySelectorAll("input[aposta]");
    var i=0; 
    var j=0; 
    var apostas={};
    while (i < x.length-1) {
        ap=x[i].id.split("_");
        apostas[j]={userid:ap[2],rodadaid:ap[3],
        jogoid : ap[4],
        status:ap[5],
        time1valor : document.getElementById(x[i].id).value,
        time2valor : document.getElementById(x[i+1].id).value}
        j++;
        i+=2;
    }
    apostas.tam= j;
    par = `par=${JSON.stringify(apostas)}`;
    doPost(serverPath + "apostas/gravar",par,gravaApostasApiRet);
}

function gravaApostasApiRet(retorno){
    ret=JSON.parse(retorno);
    if(ret.error){
        cabecalho="ERRO !!!";
    }
    if(ret.message) cabecalho="ATENÇÃO !!!";

    navigator.notification.alert(ret.mensagem,null,cabecalho);

}

function principalListaJogos(){
    
   var par = `par={"rodadaid":"${principalRodadas.value}","userid":"${gUser.id}"}`;
    doPost(serverPath+'apostas/getjogosrodada',par,principalLvwJogos_show);

}


function menuPrincipalInc(){
    if(principalRodadas.selectedIndex < principalRodadas.length-1){
        principalRodadas.selectedIndex++;
        principalListaJogos();
    }
}

function menuPrincipalDec(){
    if(principalRodadas.selectedIndex > 0){
        principalRodadas.selectedIndex--;
        principalListaJogos();
    }
}


function exibeTela(retorno){
    var ret = JSON.parse(retorno);

    if(ret.erros){
        navigator.notification.alert(ret.message,()=>{return;},"ATENÇÃO !!!");
        return;
    }

    novoJogoRodadas.length = 0;

    novoJogoRodadas.options[1] = new Option("SELECIONAR","0",false,true);

    for(i=1;i<=ret[0].length;i++){
        novoJogoRodadas.options[i] = new Option(ret[0][i-1].nome,ret[0][i-1].id,false,false);
    }

    principalRodadas.options[0] = new Option("SELECIONAR","0",false,true);

    for(i=1;i<=ret[0].length;i++){
        principalRodadas.options[i] = new Option(ret[0][i-1].nome,ret[0][i-1].id,false,false);
    }

    otherRodadas.options[0] = new Option("SELECIONAR","0",false,true);

    for(i=1;i<=ret[0].length;i++){
        otherRodadas.options[i] = new Option(ret[0][i-1].nome,ret[0][i-1].id,false,false);
    }

    novoJogoTime1.length = 0;

    novoJogoTime1.options[0] = new Option("SELECIONAR","0",false,true);

    for(i=1;i<=ret[1].length;i++){
        novoJogoTime1.options[i] = new Option(ret[1][i-1].nome,ret[1][i-1].id,false,false);
    }

    novoJogoTime2.length = 0;

    novoJogoTime2.options[0] = new Option("SELECIONAR","0",false,true);

    for(i=1;i<=ret[1].length;i++){
        novoJogoTime2.options[i] = new Option(ret[1][i-1].nome,ret[1][i-1].id,false,false);
    }


    doPost(serverPath+'apostas/ranking',`par={"userid":"${gUser.id}","per":"1"}`,(result)=>{
        res = JSON.parse(result);
        
        for(i=0;i<=res.rkg.length-1;i++){
    
            if(res.rkg[i].userid==gUser.id){ // achou ele
              posicao.innerHTML = (res.rkg[i].pontos);
              lblNome.innerHTML = i+1 + "º lugar";  //ou i+1 não sei
              userFoto.src="https://www.devicecontrols.com.br/bolao/"+res.rkg[i].userid +".jpg"
            }
    
        }
    });
    
}

// Noticias
function noticias_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Noticias","showBackButton",);
   
    document.getElementById(currView).style.display="none";
    currView = "noticia";
    document.getElementById(currView).style.display="block";


    removeToast();
    
}


//sites dos jogos ::tom::
function news()
{
    var ref = cordova.InAppBrowser.open("https://globoesporte.globo.com/futebol/brasileirao-serie-a/", '_blank', 'location=yes');
}
function news2()
{
    var ref = cordova.InAppBrowser.open("https://esporte.uol.com.br/futebol/campeonatos/brasileirao/2018/noticias/", '_blank', 'location=yes');
}
function news3()
{
    var ref = cordova.InAppBrowser.open("http://www.espn.com.br/futebol/liga/_/nome/bra.1", '_blank', 'location=yes');
}

//ver outros jogadores

gSecId=0;
function outher_gamers_Show(userid) {

    gUserId = userid;

    rodape.style.display="none";
    
    configAppBarBasics("Palpites","showBackButton");

    document.getElementById(currView).style.display="none";
    currView = "outher_gamers";
    document.getElementById(currView).style.display="block";

    removeToast();

}



function otherInc(){
    if(otherRodadas.selectedIndex < otherRodadas.length-1){
        otherRodadas.selectedIndex++;
        otherListaJogosInspect();
    }
}

function otherDec(){
    if(otherRodadas.selectedIndex > 0){
        otherRodadas.selectedIndex--;
        otherListaJogosInspect();
    }
}

function otherListaJogosInspect(){
    var par = `par={"rodadaid":"${otherRodadas.value}","userid":"${gUserId}"}`;
    doPost(serverPath+'apostas/getjogosrodada',par,otherLvwJogos_show); 

}

    function otherLvwJogos_show(retorno){
    

        if(retorno.indexOf("erros")!=-1){
    
            var ret = JSON.parse(retorno);
    
            if(ret.erros){
                navigator.notification.alert(ret.message,()=>{return;},"ERRO !!");
                return;
            }
        
            if(ret.mensagem){
                navigator.notification.alert(ret.message,()=>{return;},"ATENÇÂO !!");
                return;
            }
        
        }
    
        var ret = JSON.parse(retorno);
        i=0;
        var htmlStr=`<tr><td align="center">`;
        corTexto="white";
        expirou="livre";
        cmdApostar.style.display="none";
        while(i<=ret.length-1){
            corTexto="white";
            if(ret[i].status=="ANDAMENTO"){
                corTexto="green";
                cordofundo="yellow";
                expirou ="Andamento";
    
            } else {
                if(ret[i].status=="EXPIRADO"){
                    cordofundo="red";
                    expirou ="Encerrado";
        
                }  else{
                    cordofundo="green";
                    expirou ="Apostar";
                }
            }
    
            var auxJogo = ret[i].expira.split(' ');
            var dataJogo = auxJogo[0].split('-');
    
            var bonus=""
            if(ret[i].bonus=='1'){
                bonus="BONUS";
            }
    
            
            htmlStr  = htmlStr + 
            `
            <table class="box_better">
            <tr>
                <td align="center"></td>
                <td align="center" class="local_Part">ARENA JACARE</td>
                <td align="center" class="statusGame" style="background:${cordofundo}">${expirou}</td>
                <td align="center" class="local_Part">ARENA JACARE</td>
                <td  align="center"></td>
            </tr>
            <tr>
                <td align="center"><img src="img/${ret[i].time1nome}.png" width="40px" height="40px"></td>
                <td align="center" class="time">${ret[i].time1nome}</td>
                <td align="center" class="relogio">${auxJogo[1]}</td>
                <td align="center" class="time">${ret[i].time2nome}</td>
                <td  align="center"><img src="img/${ret[i].time2nome}.png" width="40px" height="40px"></td>
            </tr>
            <tr>
                <td align="center" class="Result" value="${ret[i].aposta1}">${ret[i].time1res}</td>
                <td align="center"><input aposta="a" id="ap_2_${gUser.id}_${ret[i].rodadaid}_${ret[i].id}_${expirou}" type="number" maxlength="2" style="background:#C0C0C0" class="inserir_Result" disabled value="${ret[i].aposta1}"></td>
                <td align="center" class="dataGame">${dataJogo[2]}/${dataJogo[1]}/${dataJogo[0]}</td>
                
                <td align="center"><input aposta="a" id="ap_2_${gUser.id}_${ret[i].rodadaid}_${ret[i].id}_${expirou}" type="number" style="background:#C0C0C0" maxlength="2" class="inserir_Result" disabled value="${ret[i].aposta2}"></td>
                <td align="center"class="Result" value="${ret[i].aposta2}">${ret[i].time2res}</td>  
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td class="bonus">${bonus}</td>
                <td></td>
                <td style="float:right"> 
            </tr>
        </table>
        <br>

    `;

         i++; 
        }    
        htmlStr=htmlStr + "</td></tr>";
        otherLvwJogos.innerHTML = htmlStr; 
    }
    
    
 //Perfil
 function perfil_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Perfil","hideBackButton");

    document.getElementById(currView).style.display="none";
    currView = "Perfil";
    document.getElementById(currView).style.display="block";
    document.getElementById("appBarLeftButtonImage").src="img/botao_voltar.png";

    userFoto.src = `https://www.devicecontrols.com.br/bolao/${gUser.id}.jpg?v=xxx`;

    removeToast();

}

function uploadPhoto(imgURI){
    //alert(imgURI);
    userFoto.src = imgURI+"?v=xxx";var options = new FileUploadOptions();
    options.fileKey="file";
    options.fileName=imgURI.substr(imgURI.lastIndexOf('/')+1);
    options.mimeType="image/jpeg";
    
    var params = new Object();
    params.user_id = gUser.id;
    
    options.params = params;
    options.chunkedMode = false;   alert(imgURI);
    var ft = new FileTransfer();
    ft.upload(imgURI,"https://www.devicecontrols.com.br/bolao/ws_saveimage.php", win, fail, options);
}

function win(r) {
    if(r.response.indexOf("Erro")!=-1){
        navigator.notification.alert(r.response,()=>{return;},"ERRO !!!");
        return;
    }
}

function fail(error) {
    navigator.notification.alert(`Erro de comunicção com o servidor. Código:${error.code}'}`,()=>{return;},"ERRO !!!");
}


function menuPrincipalFoto(){
    navigator.camera.getPicture(
        uploadPhoto,
        function (message) { alert('get picture failed'); },
        {
            quality: 50,
            destinationType: navigator.camera.DestinationType.FILE_URI,
            sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY
        }
    );




}

//Pontuação

function ranking_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Ranking","showBackButton");

    document.getElementById(currView).style.display="none";
    currView = "Ranking";
    document.getElementById(currView).style.display="block";


    removeToast();

}

function rankingMensal(){

    doPost(serverPath+'apostas/ranking',`par={"userid":"${gUser.id}","per":"1"}`,(result)=>{
        res = JSON.parse(result);

        if(res.error){
            navigator.notification.alert(res.message,()=>{return;},"ERRO !!!");
            return;
        }

        if(res.mensagem){
            navigator.notification.alert(res.message,()=>{return;},"ATENÇÃO !!!");
            return;
        }

         tabela="";
        
        for(i=0;i<=res.rkg.length-1;i++){
            border= "border-bottom:1px solid #808080;"; 
            if(i==0) border = "border-top:1px solid #808080;border-bottom:1px solid #808080";

            tabela = tabela + `<div >
            <table style="background: blue"> 
                <tr  class="box_ranking"  onclick="outher_gamers_Show(${res.rkg[i].userid});">
                    <td style="${border}">
                        <table>
                            <tr>           
                                <td><img src="https://www.devicecontrols.com.br/bolao/${res.rkg[i].userid}.jpg" onerror="gloadUserIcon(this);" style="width: 50px;height:50px;margin-left:3px;border-radius:50%;"></td>
                                    <td><p>${res.rkg[i].username}</p></td>
                                    <td class="pontos_ranking"><p>${res.rkg[i].pontos}</p></td>
                             </tr>
                        </table>
                    </td>
                </tr>             
            </table>
            </div>`;   

        }
        pontos = res.pontos;
        lvwRankList.innerHTML = tabela;
        
    });

}



function rankingRodada(){

    doPost(serverPath+'apostas/ranking',`par={"userid":"${gUser.id}","per":"2"}`,(result)=>{
        res = JSON.parse(result);

        if(res.error){
            navigator.notification.alert(res.message,()=>{return;},"ERRO !!!");
            return;
        }

        if(res.mensagem){
            navigator.notification.alert(res.message,()=>{return;},"ATENÇÃO !!!");
            return;
        }

        tabela="";
        border= "border-bottom:1px solid #808080;"; 
        if(i==0) border = "border-top:1px solid #808080;border-bottom:1px solid #808080";
        
        for(i=0;i<=res.rkg.length-1;i++){
            tabela = tabela + `<div >
            <table style="background: blue"> 
                <tr  class="box_ranking"  onclick="outher_gamers_Show(${res.rkg[i].userid});">
                    <td style="${border}">
                        <table>
                            <tr>           
                                <td><img src="https://www.devicecontrols.com.br/bolao/${res.rkg[i].userid}.jpg" onerror="gloadUserIcon(this);" style="width: 50px;height:50px;margin-left:3px;border-radius:50%;"></td>
                                    <td><p>${res.rkg[i].username}</p></td>
                                    <td class="pontos_ranking"><p>${res.rkg[i].pontos}</p></td>
                             </tr>
                        </table>
                    </td>
                </tr>             
            </table>
            </div>`;   

        }
        pontos = res.pontos;

        lvwRankList.innerHTML = tabela;

    });
    

}





function rankingAnual(){

    doPost(serverPath+'apostas/ranking',`par={"userid":"${gUser.id}","per":"2"}`,(result)=>{
        res = JSON.parse(result);

        if(res.error){
            navigator.notification.alert(res.message,()=>{return;},"ERRO !!!");
            return;
        }

        if(res.mensagem){
            navigator.notification.alert(res.message,()=>{return;},"ATENÇÃO !!!");
            return;
        }

        tabela="";
        border= "border-bottom:1px solid #808080;"; 
        if(i==0) border = "border-top:1px solid #808080;border-bottom:1px solid #808080";
        
        for(i=0;i<=res.rkg.length-1;i++){
            tabela = tabela + `<div >
            <table style="background: blue"> 
                <tr  class="box_ranking"  onclick="outher_gamers_Show(${res.rkg[i].userid});">
                    <td style="${border}">
                        <table>
                            <tr>           
                                <td><img src="https://www.devicecontrols.com.br/bolao/${res.rkg[i].userid}.jpg" onerror="gloadUserIcon(this);" style="width: 50px;height:50px;margin-left:3px;border-radius:50%;"></td>
                                    <td><p>${res.rkg[i].username}</p></td>
                                    <td  class="pontos_ranking"><p>${res.rkg[i].pontos}</p></td>
                             </tr>
                        </table>
                    </td>
                </tr>             
            </table>
            </div>`;   

        }
        pontos = res.pontos;

        lvwRankList.innerHTML = tabela;

    });
    

}

// Regras
function regras_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Regras","showBackButton");

    removeToast();
    
    document.getElementById(currView).style.display="none";
    currView = "regras";
    document.getElementById(currView).style.display="block";


}

function pontuacao_Show()
{
    rodape.style.display="none";
    
    configAppBarBasics("Regras Pontos","hideBackButton");

    document.getElementById(currView).style.display="none";
    currView = "pontuacao";
    pontuacao.style.display = "block";

    removeToast();
}

//TELA termos 


function termo_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Termos de uso","showBackButton");
    
    document.getElementById(currView).style.display="none";
    currView = "termo";
    document.getElementById(currView).style.display="block";

    removeToast();

}
 






