﻿//TELA MENU PRINCIPAL
gSecId=0;
var lblNome = document.getElementById("menprinclblNome");
var posicao = document.getElementById("pontosUser");
//funçao Show
function menu_principal_Show() {
   
    rodape.style.display="none";
    
    configAppBarBasics("Jogos","showBackButton");
    document.getElementById("imgAppBarButton1").src="img/icone_sobrea3otica.png";
    document.getElementById("appBarButton1").style.display="block";
    document.getElementById("imgAppBarButton2").src="img/world.png";
    document.getElementById("appBarButton2").style.display="block";
    document.getElementById("imgAppBarButton4").src="img/icone_faleconosco2.png";
    document.getElementById("imgAppBarButton4").style.display="block";
    document.getElementById("appBarButton4").style.display="block";

    if(gUser.adm!=1){
        document.getElementById("imgAppBarButton3").src="img/admin.png";
        document.getElementById("appBarButton3").style.display="none";

    } else {
        document.getElementById("imgAppBarButton3").src="img/admin.png";
        document.getElementById("appBarButton3").style.display="block";
    }

    document.getElementById(currView).style.display="none"; 
    currView = "menu_principal"; 
    document.getElementById(currView).style.display="block";


    var par = "par=";
    doPost(serverPath+'jogos/loadconfigs','par={"nome":"1"}',exibeTela);    

    removeToast();

}






function principalSalvaAposta(indice, jogoid,status){
    var txtres1 = document.getElementById(`principaltxt_time1_${indice}`);
    var txtres2 = document.getElementById(`principaltxt_time2_${indice}`);
    
    
    //var status = document.getElementById(`jogoStatus_${indice}`); Apostar is not defined! qaul linha



    if(status=="Encerrado"){ //agora quem expirou fala periodo expirado quem não expirou tambem!!!!!!!!
        navigator.notification.alert("Período de apostas encerrado !",()=>{return;},"ATENÇÃO !!!");
        return;
    }

    if(status=="Andamento"){ //agora quem expirou fala periodo expirado quem não expirou tambem!!!!!!!!
        navigator.notification.alert("Jogo em andamento !",()=>{return;},"ATENÇÃO !!!");
        return;
    }


    if(txtres1.value==""){
        showToast("Resultado time 1 inválido!",2000);
        return;
    }

    if(txtres2.value==""){
        showToast("Resultado time 2 inválido!",2000);
        return;
    }


    var par = `par={"jogoid":"${jogoid}",
                    "rodadaid":"${principalRodadas.value}",
                    "userid":"${gUser.id}",     
                    "time1res":"${txtres1.value}", 
                    "time2res":"${txtres2.value}"}`;
    doPost(serverPath+'apostas/salvar',par,principalListaJogos);

}

function principalLvwJogos_show(retorno){
    

    if(retorno.indexOf("erros")!=-1){

        var ret = JSON.parse(retorno);

        if(ret.erros){
            navigator.notification.alert(ret.message,()=>{return;},"ERRO !!");
            return;
        }
    
        if(ret.mensagem){
            navigator.notification.alert(ret.message,()=>{return;},"ATENÇÂO !!");
            return;
        }
    
    }

    var ret = JSON.parse(retorno);
    i=0;
    var htmlStr=`<tr><td align="center">`;
    corTexto="white";
    expirou="livre";
    disa="";

    cmdApostar.style.display="none";
    while(i<=ret.length-1){
        corTexto="white";
        if(ret[i].status=="ANDAMENTO"){
            corTexto="green";
            cordofundo="yellow";
            expirou ="Andamento";
            disa="disabled";

        } else {
            if(ret[i].status=="EXPIRADO"){
                cordofundo="red";
                expirou ="Encerrado";
                disa="disabled";
            }  else{
                cordofundo="green";
                expirou ="Apostar";
                disa="";
            }
        }

        var auxJogo = ret[i].expira.split(' ');
        var dataJogo = auxJogo[0].split('-');

        var bonus=""
        if(ret[i].bonus=='1'){
            bonus="BONUS";
        }

        t1Nome = ret[i].time1nome.toLowerCase();
        t2Nome = ret[i].time2nome.toLowerCase();;
        
        htmlStr  = htmlStr + 
        `
        <table class="box_better" style="width:100%">
        <tr>
            <td align="center" style="width: 10%"></td>
            <td style="width: 30%" align="center" class="local_Part"><label>${ret[i].local}</label></td>
            <td style="width: 20%" align="center" class="statusGame" style="background:${cordofundo}">${expirou}</td>
            <td style="width: 30%" align="center" class="local_Part"><label>${ret[i].local}</label></td>
            <td  align="center" style="width: 10%"></td>
        </tr>
        <tr>
            <td style="width: 10%" align="center"><img src="img/${t1Nome}.png" width="90%" height="30px"></td>
            <td style="width: 30%" align="center" class="time">${ret[i].time1nome}</td>
            <td style="width: 20%" align="center" class="relogio">${auxJogo[1]}</td>
            <td style="width: 30%" align="center" class="time">${ret[i].time2nome}</td>
            <td style="width: 10%"  align="center"><img src="img/${t2Nome}.png" width="90%" height="30px"></td>
        </tr>
        <tr>
            <td style="width: 10%" align="center" class="Result" value="${ret[i].aposta1}">${ret[i].time1res}</td>
            <td style="width: 30%" align="center"><input ${disa} aposta="a" id="ap_1_${gUser.id}_${ret[i].rodadaid}_${ret[i].id}_${expirou}" type="number" maxlength="2" class="inserir_Result" value="${ret[i].aposta1}"></td>
            <td style="width: 20%" align="center" class="dataGame">${dataJogo[2]}/${dataJogo[1]}/${dataJogo[0]}</td>
            <td style="width: 30%" align="center"><input ${disa} aposta="a" id="ap_2_${gUser.id}_${ret[i].rodadaid}_${ret[i].id}_${expirou}" type="number" maxlength="2" class="inserir_Result" value="${ret[i].aposta2}"></td>
            <td style="width: 10%" align="center"class="Result" value="${ret[i].aposta2}">${ret[i].time2res}</td>  
        </tr>
        <tr>
            <td style="width:10%"></td>
            <td style="width:30%"></td>
            <td style="width: 20%" class="bonus">${bonus}</td>
            <td style="width:30%"></td>
            <td style="width:10%" style="float:right">
        </tr>
    </table>
    <br>
`;
        i++;
    }    
    htmlStr=htmlStr + "</td></tr>";
    principalLvwJogos.innerHTML = htmlStr;

    if(ret.length > 0) cmdApostar.style.display="block";

    

    

}



function salvarApostas(){

    var x = document.querySelectorAll("input[aposta]");
    var i=0; 
    var j=0; 
    var apostas={};
    while (i < x.length-1) {
        ap=x[i].id.split("_");
        apostas[j]={userid:ap[2],rodadaid:ap[3],
        jogoid : ap[4],
        status:ap[5],
        time1valor : document.getElementById(x[i].id).value,
        time2valor : document.getElementById(x[i+1].id).value}
        j++;
        i+=2;
    }
    apostas.tam= j;
    par = `par=${JSON.stringify(apostas)}`;
    doPost(serverPath + "apostas/gravar",par,gravaApostasApiRet);
}

function gravaApostasApiRet(retorno){
    ret=JSON.parse(retorno);
    if(ret.error){
        cabecalho="ERRO !!!";
    }
    if(ret.message) cabecalho="ATENÇÃO !!!";

    navigator.notification.alert(ret.mensagem,null,cabecalho);

}

function principalListaJogos(){
    
   var par = `par={"rodadaid":"${principalRodadas.value}","userid":"${gUser.id}"}`;
    doPost(serverPath+'apostas/getjogosrodada',par,principalLvwJogos_show);

}


function menuPrincipalInc(){
    if(principalRodadas.selectedIndex < principalRodadas.length-1){
        principalRodadas.selectedIndex++;
        principalListaJogos();
    }
}

function menuPrincipalDec(){
    if(principalRodadas.selectedIndex > 0){
        principalRodadas.selectedIndex--;
        principalListaJogos();
    }
}


function exibeTela(retorno){
    var ret = JSON.parse(retorno);

    if(ret.erros){
        navigator.notification.alert(ret.message,()=>{return;},"ATENÇÃO !!!");
        return;
    }

    novoJogoRodadas.length = 0;

    novoJogoRodadas.options[1] = new Option("SELECIONAR","0",false,true);

    for(i=1;i<=ret[0].length;i++){
        novoJogoRodadas.options[i] = new Option(ret[0][i-1].nome,ret[0][i-1].id,false,false);
    }

    principalRodadas.options[0] = new Option("SELECIONAR","0",false,true);

    for(i=1;i<=ret[0].length;i++){
        principalRodadas.options[i] = new Option(ret[0][i-1].nome,ret[0][i-1].id,false,false);
    }

    otherRodadas.options[0] = new Option("SELECIONAR","0",false,true);

    for(i=1;i<=ret[0].length;i++){
        otherRodadas.options[i] = new Option(ret[0][i-1].nome,ret[0][i-1].id,false,false);
    }

    novoJogoTime1.length = 0;

    novoJogoTime1.options[0] = new Option("SELECIONAR","0",false,true);

    for(i=1;i<=ret[1].length;i++){
        novoJogoTime1.options[i] = new Option(ret[1][i-1].nome,ret[1][i-1].id,false,false);
    }

    novoJogoTime2.length = 0;

    novoJogoTime2.options[0] = new Option("SELECIONAR","0",false,true);

    for(i=1;i<=ret[1].length;i++){
        novoJogoTime2.options[i] = new Option(ret[1][i-1].nome,ret[1][i-1].id,false,false);
    }


    doPost(serverPath+'apostas/ranking',`par={"userid":"${gUser.id}","per":"1"}`,(result)=>{
        res = JSON.parse(result);
        
        for(i=0;i<=res.rkg.length-1;i++){
    
            if(res.rkg[i].userid==gUser.id){ // achou ele
              posicao.innerHTML = (res.rkg[i].pontos);
              lblNome.innerHTML = i+1 + "º lugar";  //ou i+1 não sei
              userFoto.src="https://www.devicecontrols.com.br/bolao/"+res.rkg[i].userid +".jpg"
            }
    
        }
    });
    
}