﻿// TELA MENU LATERAL

var menuLatInicio = document.getElementById("menuLatInicio");
var menuAdm = document.getElementById("menuAdm");


function menuLateralCompras(){
    menu_principal.style.display = "none";
    menuDeslizanteClose();
    rota('Ranking');

}

function menuLateralRanking(){
    menu_principal.style.display = "none";
    menuDeslizanteClose();
    rota('precos_produtos');

}

function menuLateralTabelaTroca(){
    menu_principal.style.display = "none";
    menuDeslizanteClose();
    rota('tabela_troca');

}


function menuLateralG1(){
    menu_principal.style.display = "none";
    menuDeslizanteClose();
    rota('noticias_g1');

}


function menuLateralSobre(){
    menu_principal.style.display = "none";
    menuDeslizanteClose();
    currView='info';
    rota("info");
    
}

function menuLateralIndique(){
    menu_principal.style.display = "none";
    menuDeslizanteClose();
    currView='info';
    rota("indicar_amigo");
    
}

function menuLateralFaleConosco(){
    menu_principal.style.display = "none";
    menuDeslizanteClose();
    rota("fale_conosco");
    
}


function menuLateralResgate(){
    menu_principal.style.display = "none";
    menuDeslizanteClose();
    currView='info_integra';
    rota("info_integra");
    
}


function menuLateralTrocaUsuario(){
    menu_principal.style.display = "none";
    menuDeslizanteClose();
    currView='login';
    rota("login");
    
}


function menuLateralSair(){

    navigator.app.exitApp();
    
}

function mdOpen() {
    mdElapsed = mdElapsed + mdStep;
    menu_lateral.style.width = mdElapsed;

    if (mdElapsed > mdStep) {
        clearInterval(mdTimer);
        mdDone = true;
    }

}

function menuDeslizanteClose() {
    menu_lateral.style.width = mdStart;
    menu_lateral.style.display = "none";
    fundoMenuLateral.style.display="none";
    mdDone = false;

}

function menuDeslizanteOpen() {
    if (!mdDone) {

        mdDone=true;
        alert(gUser.adm);
        if(gUser.adm=='0'){
            menuAdm.style.display="none";
        }
        menu_lateral.style.display = "block";
        fundoMenuLateral.style.display = "block";
        menu_lateral.style.width = mdStart;
        mdTimer = setInterval(mdOpen, mdIntervalo);

    }

}
