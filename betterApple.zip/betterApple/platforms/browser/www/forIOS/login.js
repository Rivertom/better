﻿//TELA PRE-LOGIN
var verificacaoFeita = false;
var craFormatado = "";

var loginErroCadastro = "";

var logintxtEmail = document.getElementById("logintxtEmail");
var logintxtSenha = document.getElementById("logintxtSenha");
var loginBtnLogin = document.getElementById("loginBtnLogin");

function login_Show() {

    appBar.style.display = "none";

   // logintxtCPF.focus();

   document.getElementById(currView).style.display="none";
   currView = "login";
   document.getElementById(currView).style.display="block";

    removeToast();

                var gUser = JSON.parse(localStorage.getItem("better_usuario"));
            if(gUser!=null){
                logintxtEmail.value = gUser.email;
            } else logintxtEmail.value = "";

            login.style.display = "block"; //aqui exibe  div
            
            verificacaoFeita=false;
            resetaSenha=false;
            user = null;
}

function loginCriarConta() {
    login.style.display = "none";
    rota('cadastro');

}

function loginResetarSenha() {

    if(logintxtEmail.value==""){
        alert("Favor Confira seu email ")
    }

    var par = 'par={"email":"' + logintxtEmail.value+ '"}';
    doPost(serverPath + "usuarios/solicitatrocasenha", par, (retorno)=>{
        var ret= JSON.parse(retorno);
        navigator.notification.alert(ret.message,()=>{return;},"ATENÇÂO !!!");
    });
   
}

function loginTrocaSenha(){
   navigator.notification.alert("Sua senha necessita ser alterada !",()=>{return;},"ATENÇÂO !!!");
   ///login.style.display="none";
   //rota('resgata_senha');
 navigator.notification.prompt("Nova senha:",function (results){
        if(results.buttonIndex==2){
            limpaCampos();
            return;
        }          
        
        if(results.input1==""){
            limpaCampos();
            return;
        }

        var par = 'par={"id":"' + gUser.id+ '","senha":"' + results.input1+'"}';
        doPost(serverPath + "usuarios/savesenha", par, loginSenhaTrocada);
        
    },"ATENÇÃO !!!",['Confirmar','Cancelar'],"");
 
}

function loginSenhaTrocada(retorno){

    function alertDismissed() {
        login_Show()
    }
    
    navigator.notification.alert(
        'Sua foi trocada com sucesso',  // message
        alertDismissed,         // callback
        'Senha Alterada',            // title
        'OK'                  // buttonName
    );   
    return;

}



function loginUsuarioGravado(retorno){

    gUser=JSON.parse(retorno);

    /*if(gUser.versao!="2.0.1"){
        navigator.notification.alert("Há uma nova versão disponível do aplitivo !",voidAlertCallBack,"ATENÇÂO !!!"); 
        return;

    }*/

    if(gUser.error){

        navigator.notification.alert(gUser.message,voidAlertCallBack, "ERRO !!!"); 
        return;
    }

    if(!gUser.error){
  
        if(gUser.comando){
            if(gUser.message=="REDEFINIR_SENHA"){
                loginTrocaSenha();
                return;
            }
        }

        if(gUser.mensagem){
            navigator.notification.alert(gUser.message,()=>{return;},"ATENÇÂO !!!");
            return;
        }    

        if((gUser.cpf==null)||(gUser.cep=='0')){
            navigator.notification.alert("Detectamos que seu cadastro está incompleto ! Favor completar !",
                                          cadastro_Show('alterar'),
                                          "ATENÇÃO !!!");
            return;                              
        }

        localStorage.setItem("better_usuario",retorno);
        login.style.display="none";
        var termoStatus = localStorage.getItem("betbrasil_termo");
        login.style.display="none";
        if(termoStatus==null){
            menu_principal_Show();
        } 
        else 
        {
            menu_principal_Show();
        }
        return;
    }


 
}


//resetar senha
function loginResetarSenha() {

    if(logintxtEmail.value==""){
        alert("Favor Confira seu email ")
    }

    var par = 'par={"email":"' + logintxtEmail.value+ '"}';
    doPost(serverPath + "usuarios/solicitatrocasenha", par, (retorno)=>{
        var ret= JSON.parse(retorno);
        navigator.notification.alert(ret.message,()=>{return;},"ATENÇÂO !!!");
    });
   
}

function loginEntrar_click() {
  
    
    if (logintxtEmail.value == "") {
        showToast("Favor informar o seu email !", 2000);
        logintxtEmail.focus();
        return;
    }

    if(logintxtEmail.value.indexOf("@")==-1){
        showToast("e-mail inválido !", 2000);
        logintxtEmail.focus();
        return;

    } else {
        if(logintxtEmail.value.indexOf("@")==logintxtEmail.value.length-1){
            showToast("e-mail inválido !", 2000);
            logintxtEmail.focus();
            return;
        }
    }

    if (logintxtSenha.value == "") {
        showToast("Favor informar a Senha !", 2000);
        logintxtSenha.focus();
        return;
    }


   
    
        var par = 'par={"email":"' + logintxtEmail.value+ '","senha":"' + logintxtSenha.value+'"}';
        doPost(serverPath + "usuarios/login", par, loginUsuarioGravado);
        //doGet(serverPath + "usuarios/login/"+ logintxtEmail.value+"/"+ logintxtSenha.value,loginUsuarioGravado);    
}

logintxtSenha.onkeypress= function(e) {
    if(e.keyCode==13){
        loginEntrar_click();
        return;
    }

}