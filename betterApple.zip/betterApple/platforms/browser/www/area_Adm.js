function administrador_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Administração","showBackButton");
    
    document.getElementById(currView).style.display="none";
    currView = "administracao";
    document.getElementById(currView).style.display="block";

    removeToast();
}

// Enviar Push ::Tom::

function push()
{
    navigator.notification.prompt(
        'DIGITE A MENSSAGEM PUSH',  // message
        onPrompt,                  // callback to invoke
        'Enviar Notificação',            // title
        ['Okay','Exit'],             // buttonLabels
        'Já garantiu seu premio hoje?'                 // defaultText
    );
}

function onPrompt(results) {

    if(results.buttonIndex==1)
    {
    if(results.input1.length > 140){
        alert("mensagem maior que 140 caracteres");
        return;
    }
    par = `par={"mensagem":"${results.input1}"}`;
    doPost(serverPath + "usuarios/sendpush",par,(retorno)=>{
        ret=JSON.parse(retorno)
        if(ret.erros){
            navigator.notification.alert(ret.results.input1,null,"ERRO !!!");
            return;
        }

        if(ret.message){
            navigator.notification.alert(ret.results.input1,null,"ATENÇÃO !!!");
            return;
        }

    }); 
    }
}

//Zerar Ranking Mensal / Anual ::Tom::

function zerar_ranking(){
    navigator.notification.confirm(
        'Deseja Realmente zerar o rancking?', // message
         (opcao)=>{
            if(opcao==1){
                navigator.notification.confirm(
                    'Qual rancking deseja zerar?', // message
                     (opcao)=>{
                        par="par="+opcao;
                        doPost(serverPath+"apostas/zerarancking",par,(retorno)=>{
                            ret=JSON.parse(retorno)
                            if(ret.erros){
                                navigator.notification.alert(ret.mensagem,null,"ERRO !!!");
                                return;
                            }
                    
                            if(ret.message){
                                navigator.notification.alert(ret.mensagem,null,"ATENÇÃO !!!");
                                return;
                            }
                        });
                         
                    },            // callback to invoke with index of button pressed
                    'Zerar Rancking',           // title
                    ['Mensal','Anual']);     // buttonLabels
            }
            return;
        },            // callback to invoke with index of button pressed
        'Zerar Rancking',           // title
        ['Sim','Não']);
}





