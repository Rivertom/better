
function ranking_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Ranking","showBackButton");

    document.getElementById(currView).style.display="none";
    currView = "Ranking";
    document.getElementById(currView).style.display="block";


    removeToast();

}

function rankingMensal(){

    doPost(serverPath+'apostas/ranking',`par={"userid":"${gUser.id}","per":"1"}`,(result)=>{
        res = JSON.parse(result);

        if(res.error){
            navigator.notification.alert(res.message,()=>{return;},"ERRO !!!");
            return;
        }

        if(res.mensagem){
            navigator.notification.alert(res.message,()=>{return;},"ATENÇÃO !!!");
            return;
        }

         tabela="";
        
        for(i=0;i<=res.rkg.length-1;i++){
            border= "border-bottom:1px solid #808080;"; 
            if(i==0) border = "border-top:1px solid #808080;border-bottom:1px solid #808080";

            tabela = tabela + `<div >
            <table style="background: blue"> 
                <tr  class="box_ranking"  onclick="outher_gamers_Show(${res.rkg[i].userid});">
                    <td style="${border}">
                        <table>
                            <tr>           
                                <td><img src="https://www.devicecontrols.com.br/bolao/${res.rkg[i].userid}.jpg" onerror="gloadUserIcon(this);" style="width: 50px;height:50px;margin-left:3px;border-radius:50%;"></td>
                                    <td><p>${res.rkg[i].username}</p></td>
                                    <td class="pontos_ranking"><p>${res.rkg[i].pontos}</p></td>
                             </tr>
                        </table>
                    </td>
                </tr>             
            </table>
            </div>`;   

        }
        pontos = res.pontos;
        lvwRankList.innerHTML = tabela;
        
    });

}



function rankingRodada(){

    doPost(serverPath+'apostas/ranking',`par={"userid":"${gUser.id}","per":"2"}`,(result)=>{
        res = JSON.parse(result);

        if(res.error){
            navigator.notification.alert(res.message,()=>{return;},"ERRO !!!");
            return;
        }

        if(res.mensagem){
            navigator.notification.alert(res.message,()=>{return;},"ATENÇÃO !!!");
            return;
        }

        tabela="";
        border= "border-bottom:1px solid #808080;"; 
        if(i==0) border = "border-top:1px solid #808080;border-bottom:1px solid #808080";
        
        for(i=0;i<=res.rkg.length-1;i++){
            tabela = tabela + `<div >
            <table style="background: blue"> 
                <tr  class="box_ranking"  onclick="outher_gamers_Show(${res.rkg[i].userid});">
                    <td style="${border}">
                        <table>
                            <tr>           
                                <td><img src="https://www.devicecontrols.com.br/bolao/${res.rkg[i].userid}.jpg" onerror="gloadUserIcon(this);" style="width: 50px;height:50px;margin-left:3px;border-radius:50%;"></td>
                                    <td><p>${res.rkg[i].username}</p></td>
                                    <td class="pontos_ranking"><p>${res.rkg[i].pontos}</p></td>
                             </tr>
                        </table>
                    </td>
                </tr>             
            </table>
            </div>`;   

        }
        pontos = res.pontos;

        lvwRankList.innerHTML = tabela;

    });
    

}





function rankingAnual(){

    doPost(serverPath+'apostas/ranking',`par={"userid":"${gUser.id}","per":"2"}`,(result)=>{
        res = JSON.parse(result);

        if(res.error){
            navigator.notification.alert(res.message,()=>{return;},"ERRO !!!");
            return;
        }

        if(res.mensagem){
            navigator.notification.alert(res.message,()=>{return;},"ATENÇÃO !!!");
            return;
        }

        tabela="";
        border= "border-bottom:1px solid #808080;"; 
        if(i==0) border = "border-top:1px solid #808080;border-bottom:1px solid #808080";
        
        for(i=0;i<=res.rkg.length-1;i++){
            tabela = tabela + `<div >
            <table style="background: blue"> 
                <tr  class="box_ranking"  onclick="outher_gamers_Show(${res.rkg[i].userid});">
                    <td style="${border}">
                        <table>
                            <tr>           
                                <td><img src="https://www.devicecontrols.com.br/bolao/${res.rkg[i].userid}.jpg" onerror="gloadUserIcon(this);" style="width: 50px;height:50px;margin-left:3px;border-radius:50%;"></td>
                                    <td><p>${res.rkg[i].username}</p></td>
                                    <td  class="pontos_ranking"><p>${res.rkg[i].pontos}</p></td>
                             </tr>
                        </table>
                    </td>
                </tr>             
            </table>
            </div>`;   

        }
        pontos = res.pontos;

        lvwRankList.innerHTML = tabela;

    });
    

}
