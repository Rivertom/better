function contato_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Contato","showBackButton",);

    document.getElementById(currView).style.display="none";
    currView = "contato";
    document.getElementById(currView).style.display="block";


    removeToast();
    
}

function mensagemEnviada(retorno){
    var ret = JSON.parse(retorno);
    if(ret.error){
        navigator.notification.alert(ret.message,()=>{return;},"ERRO !");
    }
    if(ret.mensagem){
        navigator.notification.alert(ret.message,()=>{return;},"ATENÇÃO !");
    }

    return;        
}        

function faleConoscoEnviar_click() {
  
            
    if (txtSugestao.value == "") {
        showToast("Favor digitar a sugestão !", 2000);
        txtSugestao.focus();
        return;
    }
   
    //mensagemEnviada("OK");
    //alert(txtSugestao.value);
    var par = `par={"nome":"${gUser.nome}","email":"${gUser.email}","mensagem":"${txtSugestao.value}"}`;
    doPost(serverPath + "usuarios/faleconosco", par, mensagemEnviada);

            
}