function regras_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Regras","showBackButton");

    removeToast();
    
    document.getElementById(currView).style.display="none";
    currView = "regras";
    document.getElementById(currView).style.display="block";


}

function pontuacao_Show()
{
    rodape.style.display="none";
    
    configAppBarBasics("Regras Pontos","hideBackButton");

    document.getElementById(currView).style.display="none";
    currView = "pontuacao";
    pontuacao.style.display = "block";

    removeToast();
}