gSecId=0;
function outher_gamers_Show(userid) {

    gUserId = userid;

    rodape.style.display="none";
    
    configAppBarBasics("Palpites","showBackButton");

    document.getElementById(currView).style.display="none";
    currView = "outher_gamers";
    document.getElementById(currView).style.display="block";

    removeToast();

}



function otherInc(){
    if(otherRodadas.selectedIndex < otherRodadas.length-1){
        otherRodadas.selectedIndex++;
        otherListaJogosInspect();
    }
}

function otherDec(){
    if(otherRodadas.selectedIndex > 0){
        otherRodadas.selectedIndex--;
        otherListaJogosInspect();
    }
}

function otherListaJogosInspect(){
    var par = `par={"rodadaid":"${otherRodadas.value}","userid":"${gUserId}"}`;
    doPost(serverPath+'apostas/getjogosrodada',par,otherLvwJogos_show); 

}

    function otherLvwJogos_show(retorno){
    

        if(retorno.indexOf("erros")!=-1){
    
            var ret = JSON.parse(retorno);
    
            if(ret.erros){
                navigator.notification.alert(ret.message,()=>{return;},"ERRO !!");
                return;
            }
        
            if(ret.mensagem){
                navigator.notification.alert(ret.message,()=>{return;},"ATENÇÂO !!");
                return;
            }
        
        }
    
        var ret = JSON.parse(retorno);
        i=0;
        var htmlStr=`<tr><td align="center">`;
        corTexto="white";
        expirou="livre";
        cmdApostar.style.display="none";
        while(i<=ret.length-1){
            corTexto="white";
            if(ret[i].status=="ANDAMENTO"){
                corTexto="green";
                cordofundo="yellow";
                expirou ="Andamento";
    
            } else {
                if(ret[i].status=="EXPIRADO"){
                    cordofundo="red";
                    expirou ="Encerrado";
        
                }  else{
                    cordofundo="green";
                    expirou ="Apostar";
                }
            }
    
            var auxJogo = ret[i].expira.split(' ');
            var dataJogo = auxJogo[0].split('-');
    
            var bonus=""
            if(ret[i].bonus=='1'){
                bonus="BONUS";
            }
    
            
            htmlStr  = htmlStr + 
            `
            <table class="box_better">
            <tr>
                <td align="center"></td>
                <td align="center" class="local_Part">ARENA JACARE</td>
                <td align="center" class="statusGame" style="background:${cordofundo}">${expirou}</td>
                <td align="center" class="local_Part">ARENA JACARE</td>
                <td  align="center"></td>
            </tr>
            <tr>
                <td align="center"><img src="img/${ret[i].time1nome}.png" width="40px" height="40px"></td>
                <td align="center" class="time">${ret[i].time1nome}</td>
                <td align="center" class="relogio">${auxJogo[1]}</td>
                <td align="center" class="time">${ret[i].time2nome}</td>
                <td  align="center"><img src="img/${ret[i].time2nome}.png" width="40px" height="40px"></td>
            </tr>
            <tr>
                <td align="center" class="Result" value="${ret[i].aposta1}">${ret[i].time1res}</td>
                <td align="center"><input aposta="a" id="ap_2_${gUser.id}_${ret[i].rodadaid}_${ret[i].id}_${expirou}" type="number" maxlength="2" style="background:#C0C0C0" class="inserir_Result" disabled value="${ret[i].aposta1}"></td>
                <td align="center" class="dataGame">${dataJogo[2]}/${dataJogo[1]}/${dataJogo[0]}</td>
                
                <td align="center"><input aposta="a" id="ap_2_${gUser.id}_${ret[i].rodadaid}_${ret[i].id}_${expirou}" type="number" style="background:#C0C0C0" maxlength="2" class="inserir_Result" disabled value="${ret[i].aposta2}"></td>
                <td align="center"class="Result" value="${ret[i].aposta2}">${ret[i].time2res}</td>  
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td class="bonus">${bonus}</td>
                <td></td>
                <td style="float:right"> 
            </tr>
        </table>
        <br>

    `;

         i++; 
        }    
        htmlStr=htmlStr + "</td></tr>";
        otherLvwJogos.innerHTML = htmlStr; 
    }
    
    
 ///
 



