function ativar_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Ativar Usuarios","showBackButton",);

    document.getElementById(currView).style.display="none";
    currView = "ativar_cads";
    document.getElementById(currView).style.display="block";


    removeToast();

    var par="par='void'";
    doPost(serverPath + 'usuarios/listaapp',par,addGamerListaUsuarios);
    
}

function addGamerStatusGravado(){

    navigator.notification.alert("Status Alterado com sucesso !",()=>{return;},"ATENÇÂO !!!");

    var par="par='void'";
    doPost(serverPath + 'usuarios/listaapp',par,addGamerListaUsuarios);

}

function addGamerOnConfirm(buttonIndex){
    
    if(buttonIndex==1){
        status="1";
    } else status='0';
    
    var par = 'par={"status":"' + status+ '","id":"' + user_id+'"}';
    doPost(serverPath + 'usuarios/savestatus',par,addGamerStatusGravado);
    
    return;
}


function addGamerChangeStatus(id,status){ 

    user_id=id;

    navigator.notification.confirm( 
        'O que vc deseja fazer?', // mensagem
         addGamerOnConfirm,            // callback 
        'Alteraração de Status',           // titulo
        ['ATIVAR','INATIVAR']); //ok
}

function addGamerListaUsuarios(retorno){


        var ret = JSON.parse(retorno);

        if(ret.erros){
            navigator.notification.alert(ret.message,()=>{return;},"ERRO !!");
            return;
        }
    
        if(ret.mensagem){
            navigator.notification.alert(ret.message,()=>{return;},"ATENÇÂO !!");
            return;
        }
    
    

    addgamerUserList.innerHTML = ""; 
    
    i=0;

    var htmlStr=`<tr><td align="center">`;
    while(i<=ret.length-1){
        if(ret[i].ativo=="0"){
            cordofundo="red";
            status ="INATIVO";

        }
        else{
            cordofundo="green";
            status="ATIVO";
        }

        


    htmlStr = htmlStr +
    `<table class="boxAtivarPlayer" style="width:90%">  
    <tr>
    <td align="center"  class="apostar" style="background:${cordofundo};text-align:center;" onclick="addGamerChangeStatus(${ret[i].id},${ret[i].ativo})">${status}</td>
    <tr>
    <tr>
        <td><p class="label white">${ret[i].nome}</p></td>
    <tr>
    <tr>
        <td><p class="label white">${ret[i].email}</p></td>
    <tr>
    </table>
    `;
    i++;
    }
    htmlStr = htmlStr;
    addgamerUserList.innerHTML = htmlStr; 

}
