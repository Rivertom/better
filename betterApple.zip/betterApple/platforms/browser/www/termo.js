﻿//TELA PRE-LOGIN


function termo_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Termos de uso","showBackButton");
    
    document.getElementById(currView).style.display="none";
    currView = "termo";
    document.getElementById(currView).style.display="block";

    removeToast();

}

