﻿//TELA PRE-LOGIN

var cadSexo = '5';
var cadPCD ='0';
var participando ="";
var participacao_oito = document.getElementById('Rodadas_8');
var participacao = document.getElementById('mensal_um');

var gFuncaoTela = "";

function cadastro_Show(func) {

    gFuncaoTela = func;
    verificacaoFeita=false;
    rodape.style.display = "none";

    //limpaCampos();

    cadTxtNome.value = "";
    cadTxtCPF.value = "";
    cadTxtEmail.value = "";
    cadTxtDataNasc.value = "",
    cadTxtCelular.value = "";
    cadTxtFoneFixo.value = "";
    cadTxtCEP.value = "";
    cadTxtRua.value = "";
    cadTxtNumero.value = "";
    cadTxtComplemento.value = "";
    cadTxtBairro.value = "";
    cadTxtCidade.value = "";



    $('#cadTxtCPF').mask("999.999.999-99");
    $('#cadTxtCEP').mask("99999-999");
    $('#cadTxtDataNasc').mask("99/99/9999");
    $('#cadTxtCelular').mask("(99)99999-9999");
    $('#cadTxtFoneFixo').mask("(99)9999-9999");

    if(gFuncaoTela=="cadastro"){
        configAppBarBasics("Criar Conta","showBackButton");
        //divSenha.style.display = "block";
        //divRepSenha.style.display = "block";
        cadCmdCadastrar.innerHTML = "CRIAR CONTA"
    } 


    //cadTxtBairro.disabled = true;
    //cadTxtRua.disabled = true;
    //cadTxtCidade.disabled = true;


    document.getElementById(currView).style.display="none";
    currView = "cadastro";
    document.getElementById(currView).style.display="block";


    if(gFuncaoTela=="alterar"){
        configAppBarBasics("Minha Conta","showBackButton");
        //divSenha.style.display = "none";
        //divRepSenha.style.display = "none";
        cadCmdCadastrar.innerHTML = "ALTERAR"

        doPost(serverPath+'apostas/ranking',`par={"userid":"${gUser.id}","per":"1"}`,(result)=>{
            res = JSON.parse(result);
            
            for(i=0;i<=res.rkg.length-1;i++){
        
                if(res.rkg[i].userid==gUser.id){ // achou ele
                    cadUserFoto.src = "https://www.devicecontrols.com.br/bolao/"+res.rkg[i].userid +".jpg"
                }
        
            }
        });

        
   
        cadTxtNome.value = gUser.nome;

        /*
        cpfAux = gUser.cpf;
        cpf = cpfAux.substring(0,3);
        cpf=cpf+".";
        cpf=cpf+cpfAux.substring(3,6);
        cpf=cpf+".";
        cpf=cpf+cpfAux.substring(6,9);
        cpf=cpf+"-";
        cpf=cpf+cpfAux.substring(9,11);*/

        if(gUser.cpf) cadTxtCPF.value = gUser.cpf.substring(0,3) + "." + gUser.cpf.substring(3,6) + "." + gUser.cpf.substring(6,9) + "-" + gUser.cpf.substring(9,11);
        cadTxtEmail.value = gUser.email;
        cadTxtDataNasc.value = gUser.datanasc;
        if(gUser.celular) cadTxtCelular.value = "(" + gUser.celular.substring(0,2)+")"+gUser.celular.substring(2,7)+"-"+gUser.celular.substring(7,11);
        if(gUser.fixo) cadTxtFoneFixo.value = "(" + gUser.fixo.substring(0,2)+")"+gUser.fixo.substring(2,6)+"-"+gUser.fixo.substring(6,10);
        if(gUser.cep.length > 5) {
            cadTxtCEP.value = gUser.cep.substring(0,5)+"-"+gUser.cep.substring(5,8);
        } else {
            cadTxtCEP.value = "";
        }
        cadTxtRua.value = gUser.rua;
        cadTxtNumero.value = gUser.num;
        cadTxtComplemento.value= gUser.comp;
        cadTxtBairro.value = gUser.bairro;
        cadTxtCidade.value = gUser.cidade;

    } 


    removeToast();

}

function cadTestaCPF(strCPF) {
    var Soma;
    var Resto;
    Soma = 0;
    if (strCPF == "00000000000") return false;

    for (i = 1; i <= 9; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (11 - i);
    Resto = (Soma * 10) % 11;

    if ((Resto == 10) || (Resto == 11)) Resto = 0;
    if (Resto != parseInt(strCPF.substring(9, 10))) return false;

    Soma = 0;
    for (i = 1; i <= 10; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (12 - i);
    Resto = (Soma * 10) % 11;

    if ((Resto == 10) || (Resto == 11)) Resto = 0;
    if (Resto != parseInt(strCPF.substring(10, 11))) return false;
    return true;
}

function cadVerificaCPF() {

    //formataCRA(txtCRA.value);
    cpfNum = cadTxtCPF.value.replace(".", "");
    while (cpfNum.indexOf(".") != -1) {
        cpfNum = cpfNum.replace(".", "");
    }
    cpfNum = cpfNum.replace("-", "");

    if (cpfNum.length == 11) {
        if (cadTestaCPF(cpfNum)) {
           var a=1 ; //doPost(serverPath + 'BuscaDadosUsuarioPorCPF', "cpf=" + cpfNum, avaliaResultado);
        } else {

            showToast("CPF inválido. Favor verificar!", 2000);
            cadTxtCPF.focus();
        }
    } else {
        showToast("CPF inválido. Favor verificar!", 2000);
        cadTxtCPF.focus();

    }
}


function criarContaRetApi(retorno){

    var ret=JSON.parse(retorno);

    if((ret.erros)||(ret.message)) {
        if(ret.erros){
            var cabecalho = "ERRO !!!";
    
        } else {
            var cabecalho = "ATENÇÃO !!!";

        }

        alerta(ret.mensagem,cabecalho,null);
        return;
    }

}
// box cheked para participação!
function testechek_um()
{

        if ( participacao.checked ) 
        {
            participando = 1;
        }
}
function testechek_oito()
{
    
        if (participacao_oito.checked) 
        {
            participando = 8;
        }
}


function cadastroCriarConta(){

    if(gFuncaoTela=='cadastro'){
    function alertDismissed() {
        if(participando == 1)
        {
            var ref = cordova.InAppBrowser.open("https://www.mercadopago.com/mlb/checkout/start?pref_id=423155552-734c65a8-2582-4484-ae53-c3b7bf85a906", '_blank', 'location=yes');
        }
    
        if(participando == 8)
        {
            var ref = cordova.InAppBrowser.open("https://www.mercadopago.com/mlb/checkout/start?pref_id=423155552-87209249-e896-40c4-889b-873eb11cf658", '_blank', 'location=yes');
        }
    }
    
    navigator.notification.alert(
        'Sua Senha para primeiro acesso é "troca123"',  // message
        alertDismissed,         // callback
        'Cadastro Realizado com Sucesso',            // title
        'Ok entendi'                  // buttonName
    );
    }


    var cpfNum="";

    if(cadTxtNome.value==""){
        showToast("Favor Preencher o Nome !",2000);
        return;
    }

   
    if (gFuncaoTela != "preinscricao") {
        if (cadTxtCPF.value == "") {
            showToast("Favor Preencher o CPF !", 2000);
            return;
        } else {
            cpfNum = cadTxtCPF.value.replace(".", "");
            while (cpfNum.indexOf(".") != -1) {
                cpfNum = cpfNum.replace(".", "");
            }
            cpfNum = cpfNum.replace("-", "");
        }
    } else {
        if (cadTxtCPF.value != "") {
            cpfNum = cadTxtCPF.value.replace(".", "");
            while (cpfNum.indexOf(".") != -1) {
                cpfNum = cpfNum.replace(".", "");
            }
            cpfNum = cpfNum.replace("-", "");
            if(cpfNum==gUser.cpf){
                navigator.notification.alert("O CPF utilizado não pode ser o mesmo CPF do usuário do aplicativo !",null,"ATENÇÃO !!!");
                return;
            }
        }
    }

    if(cadTxtDataNasc.value==""){
        showToast("Favor Preencher a data de nascimento !",2000);
        return;
    }

    if(cadTxtDataNasc.value.length != 10){
        showToast("Data de Nascimento inválida",2000);
        return;
    }

    if (cadTxtEmail.value == "") {
        showToast("Favor informar o seu email !", 2000);
        return;
    }

    if(cadTxtEmail.value.indexOf("@")==-1){
        showToast("e-mail inválido !", 2000);
        return;

    } else {
        if(cadTxtEmail.value.indexOf("@")==cadTxtEmail.value.length-1){
            showToast("e-mail inválido !", 2000);
            return;
        }
    }

    if ((cadTxtCelular.value == "") && (cadTxtFoneFixo.value == "")) {
        showToast("Favor informar ao menos um telefone !", 2000);
        return;
    }

    cel="";
    if(cadTxtCelular.value.length > 0) {
        if(cadTxtCelular.value.length != 14) {
            showToast("Numero de Telefone Celular inválido !", 2000);
            return;
        } else {
            cel = cadTxtCelular.value.replace("(","");
            cel = cel.replace(")","");
            cel = cel.replace("-","");
        }
    }

    tel="";
    if(cadTxtFoneFixo.value.length > 0) {
        if(cadTxtFoneFixo.value.length != 13) {
            showToast("Numero de Telefone Fixo inválido !", 2000);
            return;
        } else {
            tel = cadTxtFoneFixo.value.replace("(","");
            tel = tel.replace(")","");
            tel = tel.replace("-","");

        }
    }


    /*
    if (cadTxtFoneFixo.value == "") {
        showToast("Favor informar o telefone fixo !", 2000);
        return;
    }
    */
    if (cadTxtCEP.value == "") {
        showToast("Favor informar o CEP !", 2000);
        return;
    }
 
    if (cadTxtCEP.value.length != 9) {
        showToast("CEP inválido !", 2000);
        return;
    }


    if ((cadTxtRua.value == "")||(cadTxtNumero.value == "")||(cadTxtBairro.value == "")||(cadTxtCidade.value == "")) {
        showToast("Favor informar o endereço completo !", 2000);
        return;
    }

    /*
    if(gFuncaoTela=="cadastro"){
        if (cadTxtSenha.value == "") {
            showToast("Favor informar o senha !", 2000);
            return;
        } 
    
        if (cadTxtRepSenha.value != cadTxtSenha.value) {
            showToast("Senhas não conferem !", 2000);
            return;
        }
    }
    */

    if(gFuncaoTela=="preinscricao"){

        novaConta = {nome : cadTxtNome.value.toUpperCase(), nome_social:cadTxtNomeSocial.value.toUpperCase(),
            cpf : cpfNum,
            email:cadTxtEmail.value.toUpperCase(),
            dt_nasc:cadTxtDataNasc.value,
            celular:cel,
            fixo:tel,
            cep:cadTxtCEP.value.replace("-",""),
            rua:cadTxtRua.value.toUpperCase(),
            num:cadTxtNumero.value,
            comp:cadTxtComplemento.value.toUpperCase(),
            bairro:cadTxtBairro.value.toUpperCase(),
            resp_id:gUser.Id,
            grauParenResp:cadCboParentesco.value
        }; 
    }
    if(gFuncaoTela=="cadastro"){
        novaConta = {nome : cadTxtNome.value.toUpperCase(),
            cpf : cpfNum,
            email:cadTxtEmail.value.toUpperCase(),
            dt_nasc:cadTxtDataNasc.value,
            celular:cel,
            fixo:tel,
            cep:cadTxtCEP.value.replace("-",""),
            rua:cadTxtRua.value.toUpperCase(),
            num:cadTxtNumero.value,
            comp:cadTxtComplemento.value.toUpperCase(),
            bairro:cadTxtBairro.value.toUpperCase(),
            cidade:cadTxtCidade.value.toUpperCase()
        };
    }        

    if(gFuncaoTela=="alterar"){
        novaConta = {id:gUser.id,nome : cadTxtNome.value.toUpperCase(),
            cpf : cpfNum,
            email:cadTxtEmail.value.toUpperCase(),
            dt_nasc:cadTxtDataNasc.value,
            celular:cel,
            fixo:tel,
            cep:cadTxtCEP.value.replace("-",""),
            rua:cadTxtRua.value.toUpperCase(),
            num:cadTxtNumero.value,
            comp:cadTxtComplemento.value.toUpperCase(),
            bairro:cadTxtBairro.value.toUpperCase(),
            cidade:cadTxtCidade.value.toUpperCase(),
            senha:gUser.senha
        };
    }        


    var par= 'par=' + JSON.stringify(novaConta);

    if(gFuncaoTela=="alterar"){
        doPost(gServerPath+'usuarios/alterar',par,(retorno)=>{

            var ret=JSON.parse(retorno);
    
            if(ret.erros) {
                alerta(ret.mensagem,"ERRO !!",null);
                return;
            }    
            if(ret.mensagem){
                alerta(ret.message,"ATENÇÃO !!!",null);
            }

            menu_principal_Show();

        });
    }  

    if(gFuncaoTela=="cadastro"){
        doPost(gServerPath+`usuarios/insert`,par,(retorno)=>{

            var ret=JSON.parse(retorno);
    
            if(ret.erros) {
                alerta(ret.mensagem,"ERRO !!",null);
                return;
            }    
            if(ret.message){
                alerta(ret.mensagem,"ATENÇÃO !!!",null);
            }
            localStorage.setItem("sjv_cpf_reset",cadTxtCPF.value);
        });
    }  

    if(gFuncaoTela=="preinscricao") {
        
        navigator.notification.confirm("Confirma a pré-inscrição ?",(botao)=>{
            if(botao==1){

                var t = JSON.stringify(listaTurmas.turmas[gTurmaSelInd]);
                var a = JSON.stringify(novaConta);
                par = `pturma=${t}&paluno=${a}&pusua_id=${gUser.Id}`;
                doPost(gServerPath + "TurmasInscrever", par,(retorno)=>{
        
                    var ret=JSON.parse(retorno);
            
                    if((ret.erros)||(ret.message)) {
                        if(ret.erros){
                            var cabecalho = "ERRO !!!";
                    
                        } else {
                            var cabecalho = "ATENÇÃO !!!";
                
                        }
                        alerta(ret.mensagem,cabecalho,null);
                        return;
                    }
                    comprovante_inscricao_Show(ret.texto);
                });

            }

        },"Confirmar Inscrição",['SIM','NÃO']);

    } 

}


// EVENTOS DA PAGINA

cadTxtNome.onblur = function (){
    if(cadTxtNome.value!=""){
        if(!validaInputSoLetra(cadTxtNome.value)){
            showToast("Nome contém números !",2000);
        }
    }
}

cadTxtNome.onkeypress = function (e){
    if(e.keyCode==13){
        if(cadTxtNome.value!=""){
            if(!validaInputSoLetra(cadTxtNome.value)){
                showToast("Nome contém números !",2000);
            }
        }
    }

}



cadTxtCPF.onkeypress = function (e) {
    if (e.keyCode == 13) {
        cadVerificaCPF();
    }
}

cadTxtCPF.onblur = function () {
    if (!verificacaoFeita) {
        if (cadTxtCPF.value != "") {
            cadVerificaCPF();
        }
    }
}

cadTxtCPF.onfocus = function () {
    cpfStatus = "invalido";
    verificacaoFeita = false;
}


cadTxtCEP.onkeypress = function (e) {
    if (e.keyCode == 13) {
        if(cadTxtCEP.value.length == 9){
            cadTxtRua.value = "";
            cadTxtBairro.value = "";
            cadTxtCidade.value = "";
        
            cep = cadTxtCEP.value.replace(/\D/g, '');
            doGet('https://viacep.com.br/ws/'+ cep + '/json/',preencheCepApiRet)
    
        } else{
            showToast("CEP inválido !",2000);
            return;
        }
    }

}

cadTxtCEP.onblur = function () {
    if(cadTxtCEP.value.length ==9){
        cadTxtRua.value = "";
        cadTxtBairro.value = "";
        cadTxtCidade.value = "";
        
        cep = cadTxtCEP.value.replace(/\D/g, '');
        doGet('https://viacep.com.br/ws/'+ cep + '/json/',preencheCepApiRet)
    
    } else{
            showToast("CEP inválido !",2000);
            return;
    }
}

cadTxtDataNasc.onblur = function (){
    if(cadTxtDataNasc.value!=""){

        if(!validaData(cadTxtDataNasc.value)){
            cadTxtDataNasc.focus();
            showToast("Data inválida !",2000);
        }
    }
}

cadTxtDataNasc.onkeypress = function (e){
    if(e.keyCode==13){
        if(cadTxtDataNasc.value!=""){
            if(!validaData(cadTxtDataNasc.value)){
                showToast("Data inválida !",2000);
            }
        }
    }
}

cadTxtNome.onblur = function (){
    if(cadTxtNome.value!=""){
        if(!validaInputSoLetra(cadTxtNome.value)){
            showToast("Nome contém números !",2000);
            cadTxtNome.focus();
        }
    }
}

cadTxtNome.onkeypress = function (e){
    if(e.keyCode==13){
        if(cadTxtNome.value!=""){
            if(!validaInputSoLetra(cadTxtNome.value)){
                showToast("Nome contém números !",2000);
                cadTxtNome.focus();
            }
        }
    }

}
/*
cadTxtSenha.onblur = function (){
    if(cadTxtSenha.value!=""){
        if(cadTxtSenha.value.length<6){
            showToast("Senha menor que 6 caracteres !",2000);
            cadTxtSenha.focus();
        }
        if(cadTxtSenha.value.length>8){
            showToast("Senha maior que 8 caracteres !",2000);
            cadTxtSenha.focus();
        }
    }
}

cadTxtSenha.onkeypress = function (e){
    if(e.keyCode==13){
        if(cadTxtSenha.value!=""){
            if(cadTxtSenha.value.length<6){
                showToast("Senha menor que 6 caracteres !",2000);
                cadTxtSenha.focus();
            }
            if(cadTxtSenha.value.length>8){
                showToast("Senha maior que 8 caracteres !",2000);
                cadTxtSenha.focus();
            }
        }
    }

}
*/


function preencheCepApiRet(retorno){

    dadosCep = JSON.parse(retorno);

    if(dadosCep.erro==true){
        alerta("CEP Inválido !","ERRO !!!", null);
        return;
    }

    cadTxtRua.value = dadosCep.logradouro;
    cadTxtBairro.value = dadosCep.bairro;
    cadTxtCidade.value = dadosCep.localidade;

}

function validaData(data){

    if(data.length != 10) return false;

    d = data.split("/");

    if((d[0]>31)||(d[0]<1)) return false
    if((d[1]>12)||(d[1]<1)) return false;
    if(d[2].length<4) return false;

    if(d[1]=="02") {
        if(d[0]>29) return false;
    }
    if(d[1]=="04") {
        if(d[0]>30) return false;
    }
    if(d[1]=="06") {
        if(d[0]>30) return false;
    }
    if(d[1]=="09") {
        if(d[0]>30) return false;
    }
    if(d[1]=="11") {
        if(d[0]>30) return false;
    }
    return true;

}


function validaInputSoLetra(texto){
    var filtro = /^([a-zA-Zà-úÀ-Ú]|\s+)+$/;

    if(!filtro.test(texto)){
        return false;
    }

    return true;
}

function cadGetUserImage(){

    if(gFuncaoTela=="cadastro"){
        alerta("Não é possível escolher imagem sem conta criada. Crie uma conta e depois selecione sua imagem!","ATENÇÃO !!",null);
        return;
    }

    navigator.notification.confirm("O que você desja ?",(source)=>{
        if(source==2){
            navigator.camera.getPicture(
                (imagem)=>{
                    cadUserFoto.src = imagem;
                },
                function (message) { alert('get picture failed'); },
                {
                    quality: 50,
                    destinationType: navigator.camera.DestinationType.FILE_URI,
                    sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY
                }
            );
        
        }
        if(source==1){
            navigator.camera.getPicture(
                (imagem)=>{
                    cadUserFoto.src = imagem;
                },
                function (message) { alert('get picture failed'); },
                {
                    quality: 50,
                    destinationType: navigator.camera.DestinationType.FILE_URI,
                    sourceType: navigator.camera.PictureSourceType.CAMERA
                }
            );
        
        }

    },"Sua Imagem",['Câmera','Imagem']);


}

function uploadPhoto(){
    //alert(imgURI);
    var options = new FileUploadOptions();
    options.fileKey="file";
    options.fileName=cadUserFoto.src.substr(cadUserFoto.src.lastIndexOf('/')+1);
    options.mimeType="image/jpeg";
    
    var params = new Object();
    params.user_id = gUser.id;
    
    options.params = params;
    options.chunkedMode = false;   alert(imgURI);
    var ft = new FileTransfer();
    ft.upload(cadUserFoto.src,"https://www.devicecontrols.com.br/bolao/ws_saveimage.php", win, fail, options);
}

function win(r) {
    if(r.response.indexOf("Erro")!=-1){
        navigator.notification.alert(r.response,()=>{return;},"ERRO !!!");
        return;
    }
    cadastroCriarConta();
}

function fail(error) {
    navigator.notification.alert(`Erro de comunicção com o servidor. Código:${error.code}'}`,()=>{return;},"ERRO !!!");

    //console.log("upload error source " + error.source);
    //console.log("upload error target " + error.target);
}




//TELA PRE-LOGIN

var cadSexo = '5';
var cadPCD ='0';

var gFuncaoTela = "";

