function noticias_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Noticias","showBackButton",);
   
    document.getElementById(currView).style.display="none";
    currView = "noticia";
    document.getElementById(currView).style.display="block";


    removeToast();
    
}


//sites dos jogos ::tom::
function news()
{
    var ref = cordova.InAppBrowser.open("https://globoesporte.globo.com/futebol/brasileirao-serie-a/", '_blank', 'location=yes');
}
function news2()
{
    var ref = cordova.InAppBrowser.open("https://esporte.uol.com.br/futebol/campeonatos/brasileirao/2018/noticias/", '_blank', 'location=yes');
}
function news3()
{
    var ref = cordova.InAppBrowser.open("http://www.espn.com.br/futebol/liga/_/nome/bra.1", '_blank', 'location=yes');
}