function perfil_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Perfil","hideBackButton");

    document.getElementById(currView).style.display="none";
    currView = "Perfil";
    document.getElementById(currView).style.display="block";
    document.getElementById("appBarLeftButtonImage").src="img/botao_voltar.png";

    userFoto.src = `https://www.devicecontrols.com.br/bolao/${gUser.id}.jpg?v=xxx`;

    removeToast();

}

function uploadPhoto(imgURI){
    //alert(imgURI);
    userFoto.src = imgURI+"?v=xxx";var options = new FileUploadOptions();
    options.fileKey="file";
    options.fileName=imgURI.substr(imgURI.lastIndexOf('/')+1);
    options.mimeType="image/jpeg";
    
    var params = new Object();
    params.user_id = gUser.id;
    
    options.params = params;
    options.chunkedMode = false;   alert(imgURI);
    var ft = new FileTransfer();
    ft.upload(imgURI,"https://www.devicecontrols.com.br/bolao/ws_saveimage.php", win, fail, options);
}

function win(r) {
    if(r.response.indexOf("Erro")!=-1){
        navigator.notification.alert(r.response,()=>{return;},"ERRO !!!");
        return;
    }
}

function fail(error) {
    navigator.notification.alert(`Erro de comunicção com o servidor. Código:${error.code}'}`,()=>{return;},"ERRO !!!");
}


function menuPrincipalFoto(){
    navigator.camera.getPicture(
        uploadPhoto,
        function (message) { alert('get picture failed'); },
        {
            quality: 50,
            destinationType: navigator.camera.DestinationType.FILE_URI,
            sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY
        }
    );




}