function add_games_Show() {

    rodape.style.display="none";
    
    configAppBarBasics("Adicionar Jogos","showBackButton");

    document.getElementById(currView).style.display="none";
    currView = "adicionar_jogos";
    adicionar_jogos.style.display = "block";

    removeToast();
}


function novoJogoSalvaResultado(indice, jogoid){
    var txtres1 = document.getElementById(`txt_time1_${indice}`);
    var txtres2 = document.getElementById(`txt_time2_${indice}`);

    var par = `par={"jogoid":"${jogoid}",
                    "time1res":"${txtres1.value}", 
                    "time2res":"${txtres2.value}"}`;
    doPost(serverPath+'jogos/salvaresultados',par,novoJogoListaJogos);

}

function novoJogoLvwJogos_show(retorno){

    if(retorno.indexOf("erros")!=-1){

        var ret = JSON.parse(retorno);

        if(ret.erros){
            navigator.notification.alert(ret.message,()=>{return;},"ERRO !!");
            return;
        }
    
        if(ret.mensagem){
            navigator.notification.alert(ret.message,()=>{return;},"ATENÇÂO !!");
            return;
        }
    
    }

    novoJogoLvwJogos.innerHTML = retorno;
}

function novoJogoExcluir(indice,id){

    var par = 'par={"id":"'+id+'"}';
    doPost(serverPath+'jogos/deletar',par,(retorno)=>{
        var ret=JSON.parse(retorno);

        if(ret.error){
            navigator.notification.alert(ret.message,()=>{return;},"ERRO !!!");
            return;
        }

        if(ret.mensagem){
            navigator.notification.alert(ret.message,()=>{return;},"ATENÇÃO !!!");
            return;
        }

        
    });


}

function novoJogoListaJogos(){
    
   var par = 'par={"rodadaid":"'+novoJogoRodadas.value+'"}';
    doPost(serverPath+'jogos/getjogosrodada',par,novoJogoLvwJogos_show);

}

function perfilJogoGravado(retorno){

    novoJogoForm.style.display = "none";

    var ret= JSON.parse(retorno);

    if(ret.erros){
        navigator.notification.alert(ret.message,()=>{return;},"ERRO !!!");
        return;
    } else {
        if(ret.message){
            navigator.notification.alert(ret.message,()=>{return;},"ATENÇÃO !!!");
            return;
        }
    }     

}

function novoJogoSalvar(){

    if(novoJogoRodadas.selectedIndex==0){
        showToast("Favor selecionar a rodada !",2000);
        return;
    }

    if(novoJogoDtInicio.value==""){
        showToast("Data início inválida !",2000);
        return;
    }

    if(novoJogoHrInicio.value==""){
        showToast("Hora início inválida !",2000);
        return;
    }


    if(novoJogoTime1.selectedIndex==0){
        showToast("Favor selecionar o time 1 !",2000);
        return;
    }

    if(novoJogoTime2.selectedIndex==0){
        showToast("Favor selecionar o time 2 !",2000);
        return;
    }


    if(novoJogoTime1.value==novoJogoTime2.value){
        showToast("Os dois times são iguais !",2000);
        return;
    }
    var bonus ='0';
    if(novoJogoChkBonus.checked) bonus='1';

    var time1nome = novoJogoTime1.options[novoJogoTime1.selectedIndex].innerHTML
    var time2nome = novoJogoTime2.options[novoJogoTime2.selectedIndex].innerHTML

    var par = `par={"rodadaid":"${novoJogoRodadas.value}",
    "expira":"${novoJogoDtInicio.value} ${novoJogoHrInicio.value}",
    "time1id":"${novoJogoTime1.value}",
    "time2id":"${novoJogoTime2.value}",
    "bonus":"${bonus}",
    "time1nome":"${time1nome}",
    "time2nome":"${time2nome}",
    "local":"${LocalGame.value}"}`; 
    doPost(serverPath + "jogos/insert", par, perfilJogoGravado);

}

function creatNewGame(){

    if(novoJogoRodadas.value!='0'){
        novoJogoForm.style.display="block";
    } else showToast("Favor Selecionar a rodada !",2000);
}